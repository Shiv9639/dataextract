package com.lcl.scs.dataextractengine.report.processor;

import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.lcl.scs.dataextractengine.configuration.WebClientConfig;
import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.domain.ServiceErrorResponse;
import com.lcl.scs.dataextractengine.domain.ServiceErrorResponse.ErrorMessage;
import com.lcl.scs.dataextractengine.report.constants.DataExtractReportIdConstant;
import com.lcl.scs.dataextractengine.report.constants.ReportConstants;

public abstract class DataExtractServicePreProcessor {

	@Value("${dataextract.callback.url}")
	private String callBackUrl;

	@Value("${dataextract.url}")
	private String dataExtractUrl;

	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	WebClientConfig config;
	
	private Supplier<String> getCallBackUrl = () ->{
		return new StringBuilder().append(callBackUrl).append(getAbsolutePathForReportPostProcess()).toString();
	};
	
	private Supplier<String> generateCorrelationId = () ->{
		return UUID.randomUUID().toString();
	};
	
	private Supplier<String> getDataExtractUrl = () ->{
		return new StringBuilder().append(dataExtractUrl).append("data-extract-service/extract").toString();
	};
	
	BiConsumer<DataExtractReportIdConstant, String> invokeDataExtractEngine = (reportIdConstant, fileName) -> {

		DataExtractRequest request = new DataExtractRequest();
		request.setReportId(reportIdConstant.getReportId());
		request.setExcludeReportHeaders(true);
		request.setFileName(fileName);
		String correlationId = generateCorrelationId.get();
		logger.info("DataExtract request data: {}", request);
		logger.info("Correlation Id: {}", correlationId);
		try {
			if (dataExtractUrl == null || dataExtractUrl.trim().isEmpty()) {
				logger.error(
						"DataExtractsClient :: dataExtractUrl is blank set dataextract.url value in properties files");
				return;
			}
			request.setCallBackUrl(getCallBackUrl.get());
			ResponseEntity<?> response = config.getWebClient().post().uri(getDataExtractUrl.get())
					.header(ReportConstants.CONTENT_TYPE_HEADER, MediaType.APPLICATION_JSON_VALUE)
					.header(ReportConstants.CORRELATION_ID_HEADER, correlationId).bodyValue(request).exchange()
					.flatMap(result -> {
						logger.info("app-configuration rest call back status: {}", result.statusCode());
						if (result.statusCode().is2xxSuccessful()) {
							return result.toEntity(String.class);
						} else {
							return result.toEntity(String.class);
						}
					}).block();

			if (response.getStatusCode().is2xxSuccessful()) {
				logger.info("DataExtractsClient :: correlationId : {},  Report id: {}, PcsExec Id:{}, CallBack status: {}",
						correlationId, request.getReportId(), request.getPcsExecId(), response.getStatusCode());
			} else {
				ServiceErrorResponse serviceErrorResponse = (ServiceErrorResponse) response.getBody();
				if (serviceErrorResponse != null) {
					ErrorMessage errorResponse = (serviceErrorResponse.getMessage()).get(0);
					logger.error("DataExtractsClient :: correlationId : {}, Error code: {},description: {}", correlationId, errorResponse.getCode(),
							errorResponse.getDescription());
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("DataExtractsClient :: Failed to generate report for correlationId {}", correlationId, e.getMessage());
		}
	
	};

	protected abstract String getAbsolutePathForReportPostProcess();

}

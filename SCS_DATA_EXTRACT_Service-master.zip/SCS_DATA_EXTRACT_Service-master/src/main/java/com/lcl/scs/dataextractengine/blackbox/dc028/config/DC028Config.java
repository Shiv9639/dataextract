package com.lcl.scs.dataextractengine.blackbox.dc028.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "dc028EntityManagerFactory", transactionManagerRef = "dc028TransactionManager", basePackages = {
		"com.lcl.scs.dataextractengine.blackbox.dc028" })
public class DC028Config {

	@Value("${spring.dc028.datasource.driverClassName}")
	private String driverClassName;
	
	@Value("${spring.dc028.datasource.url}")
	private String dbUrl;
	
	@Value("${spring.dc028.datasource.username}")
	private String userName;
	
	@Value("${spring.dc028.datasource.password}")
	private String password;
	
	@Bean(name = "dc028DataSource")
	@ConfigurationProperties(prefix = "spring.dc028.datasource")
	public DataSource dc028DataSource() {

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverClassName);
		dataSource.setUrl(dbUrl);
		dataSource.setUsername(userName);
		dataSource.setPassword(password);
		return dataSource;
	}

	@Bean(name = "dc028EntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean dc028EntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("dc028DataSource") DataSource dataSource) {
		return builder.dataSource(dataSource).packages("com.lcl.scs.dataextractengine.blackbox.dc028").persistenceUnit("dc028")
				.build();
	}
	
    @Bean(name = "namedJdbcdc028")
    @DependsOn("dc028DataSource")
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(@Qualifier("dc028DataSource") DataSource dc028DataSource) {
        return new NamedParameterJdbcTemplate(dc028DataSource);
    }

	@Bean(name = "dc028TransactionManager")
	public PlatformTransactionManager dc028TransactionManager(
			@Qualifier("dc028EntityManagerFactory") EntityManagerFactory dc028EntityManagerFactory) {
		return new JpaTransactionManager(dc028EntityManagerFactory);
	}
}
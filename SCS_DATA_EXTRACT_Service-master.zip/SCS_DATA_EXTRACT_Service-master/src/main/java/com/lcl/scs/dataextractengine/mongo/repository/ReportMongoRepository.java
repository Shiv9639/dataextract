package com.lcl.scs.dataextractengine.mongo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.lcl.scs.dataextractengine.document.Report;

public interface ReportMongoRepository extends MongoRepository<Report, String>{ 
	
	 @Query("{ 'RPT_ID' : ?0 }")
	 Optional<Report> findByReportId(Long id);
	

}

package com.lcl.scs.dataextractengine.util;

public enum CollectionName {
	ATSEDI214("ATSEDI214"),NETWORK_SCHEDULE("NetworkSchedule"), DC022("DC022"), DC028("DC028"), UN_PLANNED_LEFT_ON_DOCK("LeftOnDockUnPlanned"),
	PLANNED_LEFT_ON_DOCK("LeftOnDockPlanned");

	private CollectionName(String value) {
		this.value = value;
	}

	private String value;

	public String getValue() {
		return value;
	}
}

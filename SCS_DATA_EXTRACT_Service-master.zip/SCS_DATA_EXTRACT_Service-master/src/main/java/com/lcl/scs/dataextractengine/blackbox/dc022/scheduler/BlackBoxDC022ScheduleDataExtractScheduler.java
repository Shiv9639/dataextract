package com.lcl.scs.dataextractengine.blackbox.dc022.scheduler;

import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.domain.DeleteRecordRequest;
import com.lcl.scs.dataextractengine.processor.DataExtractsGenerationMongoDBProcessor;
import com.lcl.scs.dataextractengine.util.CollectionName;

@Service
public class BlackBoxDC022ScheduleDataExtractScheduler {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	DataExtractsGenerationMongoDBProcessor dataExtractsGenerationMongoDBProcessor;

	@Scheduled(cron = "0 */1 * ? * *")
	public void processDataExtractEngineMongoDb() {
		logger.info("ScheduledExecutorService getting started for DC022");
		ScheduledExecutorService executor = Executors.newScheduledThreadPool(15);
		try
		{
			executor.schedule(new Runnable() {
				public void run() {
					DataExtractRequest dataExtractRequest = new DataExtractRequest();
					dataExtractRequest.setReportId(5L);
					dataExtractRequest.setCollectionName(CollectionName.DC022);
					dataExtractRequest.setUpdateRecord(Boolean.TRUE);
					dataExtractRequest.setPrimaryFieldName("BB_ID");
					dataExtractsGenerationMongoDBProcessor.processExtractGeneration(dataExtractRequest,
							UUID.randomUUID().toString());
					logger.info("Data Extraction to MongoDB is successful for : {}",
							dataExtractRequest.getCollectionName().getValue());
				}
			}, 0, TimeUnit.MILLISECONDS);
		}
		finally
		{
			executor.shutdown();
			try {
				if (!executor.awaitTermination(2, TimeUnit.MINUTES)) {
					executor.shutdownNow();
			    } 
            } catch (InterruptedException e) {
            	executor.shutdownNow();
                logger.error(e.getMessage());
            }
			if (executor.isShutdown()) {
				logger.info("executor shutdown successfully for DC022");
			}
		}
	}

	@Scheduled(cron = "0 0 0/12 * * ?")
	public void deleteMongoRecords() {
		DeleteRecordRequest deleteRecordRequest = new DeleteRecordRequest();
		deleteRecordRequest.setCollectionName(CollectionName.DC022);
		deleteRecordRequest.setDeleteAll(Boolean.FALSE);
		deleteRecordRequest.setFieldName("WMS_TIMESTAMP");
		deleteRecordRequest.setNumberOfDays(14);
		dataExtractsGenerationMongoDBProcessor.processDeleteRecords(deleteRecordRequest);
	}

}

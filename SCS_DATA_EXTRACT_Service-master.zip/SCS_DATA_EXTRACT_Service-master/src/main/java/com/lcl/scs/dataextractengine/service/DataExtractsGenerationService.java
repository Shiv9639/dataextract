package com.lcl.scs.dataextractengine.service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.processor.DataExtractsGenerationCSVProcessor;
import com.lcl.scs.dataextractengine.processor.DataExtractsGenerationMongoDBProcessor;

/**
 * Service class to instantiate the extract generation process in separate
 * thread.
 */
@Service
public class DataExtractsGenerationService {

	/** The logger. */
	private Logger logger = LoggerFactory.getLogger(getClass());

	/** The data extracts generation processor. */
	@Autowired
	private DataExtractsGenerationCSVProcessor dataExtractsGenerationProcessor;

	/** The thread pool task executor. */
	@Autowired
	private Executor taskExecutor;

	/**
	 * Parameterized Constructor.
	 * 
	 * @param dataExtractsGenerationProcessor the data extract generation processor
	 * @param taskExecutor                    the task executor
	 */
	public DataExtractsGenerationService(DataExtractsGenerationCSVProcessor dataExtractsGenerationProcessor,
			Executor taskExecutor, DataExtractsGenerationMongoDBProcessor dbprocess) {
		this.dataExtractsGenerationProcessor = dataExtractsGenerationProcessor;
		this.taskExecutor = taskExecutor;
	}

	/**
	 * Initiates the controller in separate thread for processing the file
	 * generation.
	 *
	 * @param dataExtractRequest the data extract request
	 * @return the response entity
	 */
	// @Async("taskExecutor")
	public ResponseEntity<String> initiateExtractGeneration(DataExtractRequest dataExtractRequest,
			String correlationId) {
		try {
			CompletableFuture.runAsync(() -> {
				logger.info("Started async execution for report id: {} correlationId : {} ",
						dataExtractRequest.getReportId(), correlationId);
				dataExtractsGenerationProcessor.processExtractGeneration(dataExtractRequest, correlationId);
				logger.info("Ended async execution for report id: {} correlationId : {} ",
						dataExtractRequest.getReportId(), correlationId);
			}, taskExecutor);
		} catch (Exception ex) {
			logger.error("Exception in getExtractGeneration()", ex);
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.info("In processExtractGeneration");
		return new ResponseEntity<String>(HttpStatus.ACCEPTED);

	}

}

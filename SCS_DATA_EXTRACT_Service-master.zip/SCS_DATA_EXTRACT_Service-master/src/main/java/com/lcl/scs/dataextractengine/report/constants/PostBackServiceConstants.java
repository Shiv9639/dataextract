package com.lcl.scs.dataextractengine.report.constants;

public class PostBackServiceConstants {
	
	public static final String DC_REPORT_POST_BACK_URL = "postProcess/DCReport";
	public static final String CARRIER_MASTER_LIST_REPORT_POST_BACK_URL = "postProcess/CarrierMasterReport";
	public static final String NETWORK_SCHEDULE_DC_STORE_REPORT_POST_BACK_URL = "postProcess/networkScheduleDCStoreMap";

}

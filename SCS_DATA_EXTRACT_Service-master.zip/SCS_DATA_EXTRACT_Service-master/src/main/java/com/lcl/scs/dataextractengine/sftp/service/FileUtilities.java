package com.lcl.scs.dataextractengine.sftp.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.lcl.scs.dataextractengine.service.StoreMasterService;
import com.lcl.scs.dataextractengine.util.logging.LoggingUtilities;

@Service
public class FileUtilities {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Qualifier("namedJdbcOds")
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	private StoreMasterService storeMasterService;

	private static final String SQL_QUERY = "select ooh.fedex_tracking_number as fedex_tracking_number, REPLACE(ooh.carton,'.0','') as tote_id, ooh.DC as DC, ltrim(shpg_loc_t.shpg_loc_cd,'0') as STORE, decode(ooh.lw, '40', 'RX - DCR', '45', 'RX - DCI', '50', 'RX - DCN') commodity  \r\n"
			+ "from DALLAS_D050.outbound_order_header ooh, jdatm_prod.shpg_loc_t shpg_loc_t\r\n"
			+ "where\r\n"
			+ "ltrim(shpg_loc_t.corp1_id,'0')=substr(ooh.store,0,length(ooh.store)-2)\r\n"
			+ "and shpg_loc_t.shpg_loc_cd NOT LIKE '000009%'\r\n"
			+ "and shpg_loc_t.stat_enu = '1'\r\n"
			+ "and substr(ooh.store,0,length(ooh.store)-2) != ltrim(shpg_loc_t.shpg_loc_cd,'0')\r\n"
			+ "and shpg_loc_t.extl_cd2 like 'CUSTOMER%'\r\n"
			+ "and fedex_tracking_number in (:fedexTrackingNumbers)\r\n"
			+ "union\r\n"
			+ "select ooh.fedex_tracking_number as fedex_tracking_number, REPLACE(ooh.carton,'.0','') as tote_id, ooh.DC as DC, ltrim(shpg_loc_t.shpg_loc_cd,'0') as STORE, decode(ooh.lw, '40', 'RX - DCR', '45', 'RX - DCI', '50', 'RX - DCN') commodity  \r\n"
			+ "from DALLAS_D030.outbound_order_header ooh, jdatm_prod.shpg_loc_t shpg_loc_t\r\n"
			+ "where ltrim(shpg_loc_t.corp1_id,'0')=substr(ooh.store,0,length(ooh.store)-2)\r\n"
			+ "and shpg_loc_t.shpg_loc_cd NOT LIKE '000009%'\r\n"
			+ "and shpg_loc_t.stat_enu = '1'\r\n"
			+ "and substr(ooh.store,0,length(ooh.store)-2) != ltrim(shpg_loc_t.shpg_loc_cd,'0')\r\n"
			+ "and shpg_loc_t.extl_cd2 like 'CUSTOMER%'\r\n"
			+ "and fedex_tracking_number in (:fedexTrackingNumbers)\r\n"
			+ "union\r\n"
			+ "select distinct ch.trkg_nbr as fedex_tracking_number, ch.carton_nbr as tote_id, ch.WHSE as DC, ltrim(shpg_loc_t.shpg_loc_cd,'0') as STORE, decode(sd.ref_field_2, '40', 'RX - DCR', '45', 'RX - DCI', '50', 'RX - DCN') as commodity \r\n"
			+ "from PR827_WMOS_DATA_PROD.carton_hdr ch, PR827_WMOS_DATA_PROD.store_distro sd, jdatm_prod.shpg_loc_t shpg_loc_t\r\n"
			+ "where ch.pkt_ctrl_nbr = sd.pkt_ctrl_nbr\r\n"
			+ "and ch.whse =sd.whse\r\n"
			+ "and ltrim(shpg_loc_t.corp1_id,'0')=sd.store_nbr\r\n"
			+ "and shpg_loc_t.shpg_loc_cd not like '000009%'\r\n"
			+ "and shpg_loc_t.stat_enu = '1'\r\n"
			+ "and lpad(sd.store_nbr,4,0) != ltrim(shpg_loc_t.shpg_loc_cd,'0')\r\n"
			+ "and shpg_loc_t.extl_cd2 like 'CUSTOMER%'\r\n"
			+ "and ch.trkg_nbr in (:fedexTrackingNumbers)\r\n"
			+ "union\r\n"
			+ "select distinct ch.trkg_nbr as fedex_tracking_number, ch.carton_nbr as tote_id, ch.WHSE as DC, ltrim(shpg_loc_t.shpg_loc_cd,'0') as STORE, decode(sd.ref_field_2, '40', 'RX - DCR', '45', 'RX - DCI', '50', 'RX - DCN') as commodity \r\n"
			+ "from PR829_WMOS_DATA_PROD.carton_hdr ch, PR829_WMOS_DATA_PROD.store_distro sd, jdatm_prod.shpg_loc_t shpg_loc_t \r\n"
			+ "where ch.pkt_ctrl_nbr = sd.pkt_ctrl_nbr\r\n"
			+ "and ch.whse =sd.whse\r\n"
			+ "and ltrim(shpg_loc_t.corp1_id,'0')=sd.store_nbr\r\n"
			+ "and shpg_loc_t.shpg_loc_cd not like '000009%'\r\n"
			+ "and shpg_loc_t.stat_enu = '1'\r\n"
			+ "and lpad(sd.store_nbr,4,0) != ltrim(shpg_loc_t.shpg_loc_cd,'0')\r\n"
			+ "and shpg_loc_t.extl_cd2 like 'CUSTOMER%'\r\n"
			+ "and ch.trkg_nbr in (:fedexTrackingNumbers)\r\n"
			+ "union\r\n"
			+ "select distinct ch.trkg_nbr as fedex_tracking_number, ch.carton_nbr as tote_id, ch.WHSE as DC, ltrim(shpg_loc_t.shpg_loc_cd,'0') as STORE, decode(sd.ref_field_2, '40', 'RX - DCR', '45', 'RX - DCI', '50', 'RX - DCN') as commodity \r\n"
			+ "from PR078_WMOS_DATA_PROD.carton_hdr ch, PR078_WMOS_DATA_PROD.store_distro sd, jdatm_prod.shpg_loc_t shpg_loc_t\r\n"
			+ "where ch.pkt_ctrl_nbr = sd.pkt_ctrl_nbr\r\n"
			+ "and ch.whse =sd.whse\r\n"
			+ "and ltrim(shpg_loc_t.corp1_id,'0')=sd.store_nbr\r\n"
			+ "and shpg_loc_t.shpg_loc_cd not like '000009%'\r\n"
			+ "and shpg_loc_t.stat_enu = '1'\r\n"
			+ "and lpad(sd.store_nbr,4,0) != ltrim(shpg_loc_t.shpg_loc_cd,'0')\r\n"
			+ "and shpg_loc_t.extl_cd2 like 'CUSTOMER%'\r\n"
			+ "and ch.trkg_nbr in (:fedexTrackingNumbers)\r\n"
			+ "union\r\n"
			+ "select distinct ch.trkg_nbr as fedex_tracking_number, ch.carton_nbr as tote_id, ch.WHSE as DC, ltrim(shpg_loc_t.shpg_loc_cd,'0') as STORE, decode(sd.ref_field_2, '40', 'RX - DCR', '45', 'RX - DCI', '50', 'RX - DCN') as commodity \r\n"
			+ "from PR830_WMOS_DATA_PROD.carton_hdr ch, PR830_WMOS_DATA_PROD.store_distro sd, jdatm_prod.shpg_loc_t shpg_loc_t \r\n"
			+ "where ch.pkt_ctrl_nbr = sd.pkt_ctrl_nbr\r\n"
			+ "and ch.whse =sd.whse\r\n"
			+ "and ltrim(shpg_loc_t.corp1_id,'0')=sd.store_nbr\r\n"
			+ "and shpg_loc_t.shpg_loc_cd not like '000009%'\r\n"
			+ "and shpg_loc_t.stat_enu = '1'\r\n"
			+ "and lpad(sd.store_nbr,4,0) != ltrim(shpg_loc_t.shpg_loc_cd,'0')\r\n"
			+ "and shpg_loc_t.extl_cd2 like 'CUSTOMER%'\r\n"
			+ "and ch.trkg_nbr in (:fedexTrackingNumbers)\r\n"
			+ "union\r\n"
			+ "select distinct ch.trkg_nbr as fedex_tracking_number, ch.carton_nbr as tote_id, ch.WHSE as DC, ltrim(shpg_loc_t.shpg_loc_cd,'0') as STORE, decode(sd.ref_field_2, '40', 'RX - DCR', '45', 'RX - DCI', '50', 'RX - DCN') as commodity \r\n"
			+ "from PR828_WMOS_DATA_PROD.carton_hdr ch, PR828_WMOS_DATA_PROD.store_distro sd, jdatm_prod.shpg_loc_t shpg_loc_t\r\n"
			+ "where ch.pkt_ctrl_nbr = sd.pkt_ctrl_nbr\r\n"
			+ "and ch.whse =sd.whse\r\n"
			+ "and ltrim(shpg_loc_t.corp1_id,'0')=sd.store_nbr\r\n"
			+ "and shpg_loc_t.shpg_loc_cd not like '000009%'\r\n"
			+ "and shpg_loc_t.stat_enu = '1'\r\n"
			+ "and lpad(sd.store_nbr,4,0) != ltrim(shpg_loc_t.shpg_loc_cd,'0')\r\n"
			+ "and shpg_loc_t.extl_cd2 like 'CUSTOMER%'\r\n"
			+ "and ch.trkg_nbr in (:fedexTrackingNumbers)";

	@SuppressWarnings("deprecation")
	public byte[] doFileChange(byte[] fileBytes,List<String> headers, int selectedFieldIndex, String extendFieldName) {
		CSVParser csvParser = null;
		InputStream clone1 = null, clone2 = null;
		Reader reader = null, in = null;
		Writer writer = null;
		CSVPrinter csvPrinter = null;
		Path tempFile = null;
		try {
			
			clone1 = new ByteArrayInputStream(fileBytes);
			clone2 = new ByteArrayInputStream(fileBytes);
			reader = new InputStreamReader(clone1);
			csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader());
			headers.add(extendFieldName);
			headers.add("DC");
			headers.add("STORE");
			headers.add("COMMODITY");
			
			
			List<String> selectedFieldValues = csvParser.getRecords().stream()
					.map(r -> r.get(selectedFieldIndex).trim()).collect(Collectors.toList());
			Map<String, List<String>> extendedData = executeExtractQuerySql(selectedFieldValues);

			CSVFormat csvFileFormat = CSVFormat.EXCEL.withHeader(headers.toArray(new String[headers.size()]));
			tempFile = Files.createTempFile("", ".csv");
			writer = Files.newBufferedWriter(tempFile);
			csvPrinter = new CSVPrinter(writer, csvFileFormat);

			in = new InputStreamReader(clone2);
			Iterable<CSVRecord> records = CSVFormat.DEFAULT
					.withHeader(headers.toArray(new String[headers.size()]))
					.withFirstRecordAsHeader().parse(in);
			for (CSVRecord row : records) {
				String selectedFieldValue = row.get(selectedFieldIndex).trim();
				String dataArray[] = new String[headers.size()];
				for (int i = 0; i < headers.size(); i++) {
					if (i <= (headers.size() - 5)) {
						
						if(headers.get(i).equals("DELVT") || headers.get(i).equals("STATC") || headers.get(i).equals("ESTDT")) {
							dataArray[i] = "\"" + row.get(headers.get(i)) + "\"";
						}else {
							dataArray[i] = row.get(headers.get(i));
							
						}	
						
					} else if(i == (headers.size() - 4)){
						if(extendedData.get(selectedFieldValue) != null) {
							dataArray[i] = "\""+ extendedData.get(selectedFieldValue).get(0) +"\"";
						}
					}
					else if(i == (headers.size() - 3)){
						if(extendedData.get(selectedFieldValue) != null) {
							dataArray[i] = extendedData.get(selectedFieldValue).get(1);
						}
					}else if(i == (headers.size() - 2)){
						if(extendedData.get(selectedFieldValue) != null) {
							dataArray[i] = extendedData.get(selectedFieldValue).get(2);
						}
					}else if(i == (headers.size() - 1)){
						if(extendedData.get(selectedFieldValue) != null) {
							dataArray[i] = extendedData.get(selectedFieldValue).get(3);
						}
					}
				}
				csvPrinter.printRecord(dataArray);
				
				
			}
			csvPrinter.flush();
			return Files.readAllBytes(tempFile);
		} catch (Exception e) {
			LoggingUtilities.generateErrorLog(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				Files.delete(tempFile);
			} catch (IOException e1) {
				logger.error(e1.getMessage());
			}
			if (csvParser != null) {
				try {
					csvParser.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (clone1 != null) {
				try {
					clone1.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (clone2 != null) {
				try {
					clone2.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (csvPrinter != null) {
				try {
					csvPrinter.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
		return null;
	}

	private Map<String, List<String>> executeExtractQuerySql(List<String> fedexTrackingNumbers) {
		Map<String, List<String>> resultMap = new HashMap<String, List<String>>();
        final int chunkSize = 1000;
        final AtomicInteger counter = new AtomicInteger();
        final Collection<List<String>> splittedResult = fedexTrackingNumbers.stream()
                .collect(Collectors.groupingBy(it -> counter.getAndIncrement() / chunkSize))
                .values();
        for(List<String> trackingNumbers : splittedResult) {
            MapSqlParameterSource namedParameters = new MapSqlParameterSource();
			namedParameters.addValue("fedexTrackingNumbers", trackingNumbers);
			try {
				namedParameterJdbcTemplate.getJdbcTemplate().setFetchSize(10000);
				namedParameterJdbcTemplate.query(SQL_QUERY, namedParameters, new ResultSetExtractor<Integer>() {
					int resultsCount = 0;
					@Override
					public Integer extractData(final ResultSet rs) {
						try {
							while (rs.next()) {
								resultsCount++;
								ArrayList<String> results = new ArrayList<>();
								results.add(rs.getString("TOTE_ID"));
								results.add(rs.getString("DC"));
								results.add(rs.getString("STORE"));
								results.add(rs.getString("COMMODITY"));
								
								resultMap.put(rs.getString("FEDEX_TRACKING_NUMBER").trim(), results);
							}
						} catch (final SQLException ex) {
							resultsCount = -1;
							logger.error("Exception in executeExtractQuerySql()", ex);
						}
						logger.info("No. of records are being processed: {}", resultsCount);
						return resultsCount;
					}
				});
			} catch(Exception e){
				LoggingUtilities.generateErrorLog(e.getMessage());
			}
        }
        
		return resultMap;
		
	}
}

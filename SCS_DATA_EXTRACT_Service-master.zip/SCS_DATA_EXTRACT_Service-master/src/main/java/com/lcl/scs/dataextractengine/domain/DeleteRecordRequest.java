package com.lcl.scs.dataextractengine.domain;

import org.bson.conversions.Bson;

import com.lcl.scs.dataextractengine.util.CollectionName;

public class DeleteRecordRequest {
	private CollectionName collectionName;
	private boolean isDeleteAll;
	private String fieldName;
	private int numberOfDays;
	private Bson filter;

	public CollectionName getCollectionName() {
		return collectionName;
	}

	public void setCollectionName(CollectionName collectionName) {
		this.collectionName = collectionName;
	}

	public boolean isDeleteAll() {
		return isDeleteAll;
	}

	public void setDeleteAll(boolean isDeleteAll) {
		this.isDeleteAll = isDeleteAll;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public int getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(int numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	public Bson getFilter() {
		return filter;
	}

	public void setFilter(Bson filter) {
		this.filter = filter;
	}
}

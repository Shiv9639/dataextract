package com.lcl.scs.dataextractengine.swagger;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


/**
 * The Class SwaggerConfig.
 */
@Configuration
@Profile("dev")
public class SwaggerConfig implements WebMvcConfigurer {

    /** The build properties. */
    @Autowired
    private BuildProperties buildProperties;

    /**
     * API documentation for the Loblaw Data Extract Engine.
     *
     * @return the OpenAPI
     */
    @Bean
    public OpenAPI extractEngineOpenApi() {
        return new OpenAPI().addServersItem(new Server())
               // .components(new Components().addSecuritySchemes("basicScheme", new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("basic")))
                .info(new Info().title("Loblaw Data Extract Engine API REST API")
                        .description("API Documentation for the Loblaw Extract Engine application").version(buildProperties.getVersion()));
    }

}

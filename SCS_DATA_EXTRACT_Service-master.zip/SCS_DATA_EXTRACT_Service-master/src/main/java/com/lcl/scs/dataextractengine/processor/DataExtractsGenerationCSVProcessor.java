package com.lcl.scs.dataextractengine.processor;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.lcl.scs.dataextractengine.configuration.WebClientConfig;
import com.lcl.scs.dataextractengine.constants.DataExtractEngineConstants;
import com.lcl.scs.dataextractengine.domain.DataExtractCallBackRequest;
import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.domain.QueryResult;
import com.lcl.scs.dataextractengine.domain.ServiceErrorResponse;
import com.lcl.scs.dataextractengine.domain.ServiceErrorResponse.ErrorMessage;
import com.lcl.scs.dataextractengine.gcp.GCPFileDetails;
import com.lcl.scs.dataextractengine.gcp.GCPServiceFactory;

/**
 * Fetches the sql query from config tables , process the query and generates
 * the csv to store in file system. Finally invokes the callback for updating
 * the process execution with status and file name
 */
@Component
public class DataExtractsGenerationCSVProcessor extends DataExtractGenerationProcessor {

	/**
	 * The logger.
	 */
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private GCPServiceFactory gcsServiceFactory;

	@Value("${report.file.base.path}")
	private String filePath;

	@Autowired
	WebClientConfig config;

	public void processResults(QueryResult result, DataExtractRequest dataExtractRequest, int processedRecords,
			String fileName, String correlationId) {

		DataExtractCallBackRequest callBackRequest = new DataExtractCallBackRequest();
		callBackRequest.setReportId(dataExtractRequest.getReportId());
		callBackRequest.setPrcExecStatus(result.getResultsCount() >= 0);
		callBackRequest.setFileName(fileName);
		String data = result.getData() != null ? (String) result.getData() : StringUtils.EMPTY;
		if (result.getResultsCount() > 0 && !StringUtils.isEmpty(data)) {
			GCPFileDetails filedetails = new GCPFileDetails();
			filedetails.setFilename(fileName);
			filedetails.setData(data.getBytes());
			filedetails.setFilePath(filePath);
			callBackRequest.setFileSysRptInd(writeToGCp(filedetails));
		} else {
			callBackRequest.setFileSysRptInd(false);
		}
		logger.info("Data write to GCP is successful");
		callBackRequest.setProcessedRecordCount(result.getResultsCount());
		logger.info("Processed Records count is : {}", result.getResultsCount());
		updateProcessStatus(dataExtractRequest, correlationId, callBackRequest);
		logger.info("Updated Process status successfully");
	}

	public boolean writeToGCp(GCPFileDetails fileDetails) {
		return gcsServiceFactory.writeToGcs(fileDetails);
	}

	/**
	 * update process status.
	 *
	 * @param request           the request
	 * @param processedRecords  the number of processed records
	 * @param generatedFileName the generated file name
	 */
	public void updateProcessStatus(DataExtractRequest request, String correlationId,
			DataExtractCallBackRequest callBackRequest) {
		logger.debug("DataExtractsGenerationProcessor :: Invoking updateProcessStatus");

		logger.info("DataExtractCallBackRequest data: {}", callBackRequest);
		try {

			ResponseEntity<?> response = config.getWebClient().post().uri(request.getCallBackUrl())
					.header(DataExtractEngineConstants.CONTENT_TYPE_HEADER, MediaType.APPLICATION_JSON_VALUE)
					.header(DataExtractEngineConstants.CORRELATION_ID_HEADER, correlationId).bodyValue(callBackRequest)
					.exchange().flatMap(result -> {
						logger.info("app-configuration rest call back status: {}", result.statusCode());
						if (result.statusCode().is2xxSuccessful()) {
							return result.toEntity(String.class);
						} else {
							return result.toEntity(String.class);
						}
					}).block();

			if (response.getStatusCode().is2xxSuccessful()) {
				logger.info("DataExtractsGenerationProcessor :: Report id: {}, PcsExec Id:{}, CallBack status: {}",
						request.getReportId(), request.getPcsExecId(), response.getStatusCode());
			} else {
				ServiceErrorResponse serviceErrorResponse = (ServiceErrorResponse) response.getBody();
				if (serviceErrorResponse != null) {
					ErrorMessage errorResponse = (serviceErrorResponse.getMessage()).get(0);
					logger.error("DataExtractsGenerationProcessor :: CallBack Error code: {},description: {}",
							errorResponse.getCode(), errorResponse.getDescription());
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("DataExtractsGenerationProcessor :: Failed to update status", e.getMessage());
		}
	}

}

package com.lcl.scs.dataextractengine.document;

import java.io.Serializable;
import java.util.Date;
import java.util.StringJoiner;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.MongoId;

/**
 * The report object contains useful information about the report entry.
 */
@Document("RPT_CONFIG")
public class Report implements Serializable {
	static final long serialVersionUID = 652677942889196986L;

	@Id
	private String id;
	
	/**
	 * BI_RPT_ID.
	 */
	//@MongoId
	@Field("RPT_ID")
	private Long reportId;

	@Field(name = "RPT_NAME")
	private String reportName;

	/**
	 * QRY_TXT.
	 */
	@Field("QRY_TXT")
	private String queryText;

	/**
	 * INC_EXTR_IND -Flag to indicate report entry as an incremental extract.
	 */
	@Field("INC_EXTR_IND")
	private boolean incrementalExtractIndicator = false;

	/**
	 * PRV_INC_EXTR_CTOFF_TS - previous incremental extract cut off timestamp.
	 */
	@Field("PRV_INC_EXTR_CTOFF_TS")
	private Date previousIncrementalExtractCutOffTimestamp;

	@Field("SOURCE_TO_TRAGET")
	private String sourceToTraget;
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public Long getReportId() {
		return reportId;
	}

	public void setReportId(Long reportId) {
		this.reportId = reportId;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getQueryText() {
		return queryText;
	}

	public void setQueryText(String queryText) {
		this.queryText = queryText;
	}

	public boolean isIncrementalExtractIndicator() {
		return incrementalExtractIndicator;
	}

	public void setIncrementalExtractIndicator(boolean incrementalExtractIndicator) {
		this.incrementalExtractIndicator = incrementalExtractIndicator;
	}

	public Date getPreviousIncrementalExtractCutOffTimestamp() {
		return previousIncrementalExtractCutOffTimestamp;
	}

	public void setPreviousIncrementalExtractCutOffTimestamp(Date previousIncrementalExtractCutOffTimestamp) {
		this.previousIncrementalExtractCutOffTimestamp = previousIncrementalExtractCutOffTimestamp;
	}

	public String getSourceToTraget() {
		return sourceToTraget;
	}

	public void setSourceToTraget(String sourceToTraget) {
		this.sourceToTraget = sourceToTraget;
	}

	@Override
	public String toString() {
		return new StringJoiner(",", "Report{", "}").add("reportId=" + reportId).add("queryText='" + queryText + "'")
				.add("incrementalExtractIndicator=" + incrementalExtractIndicator)
				.add("lastIncrementalExtractCutOffTimestamp='" + previousIncrementalExtractCutOffTimestamp).toString();
	}
}

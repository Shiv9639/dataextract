package com.lcl.scs.dataextractengine.entity;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document("LeftOnDockUnPlanned")
public class LeftOnDockUnPlannedEvents {

	@Id
	@Field("_id")
	private String id;
	@Field("COMP_ELMT_ID")
	private String compElmtId;
	@Field("SHPM_ID")
	private String shpmId;
	@Field("COMMODITY")
	private String commodity;
	@Field("SHIP_NUMBER")
	private String shipNumber;
	@Field("ORIGIN_DC")
	private String originDc;
	@Field("STORE_ID")
	private String storeId;
	@Field("SCHEMAID")
	private String schemaId;
	@Field("PROCESSED")
	private String processed;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCompElmtId() {
		return compElmtId;
	}
	public void setCompElmtId(String compElmtId) {
		this.compElmtId = compElmtId;
	}
	public String getShpmId() {
		return shpmId;
	}
	public void setShpmId(String shpmId) {
		this.shpmId = shpmId;
	}
	public String getCommodity() {
		return commodity;
	}
	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}
	public String getShipNumber() {
		return shipNumber;
	}
	public void setShipNumber(String shipNumber) {
		this.shipNumber = shipNumber;
	}
	public String getOriginDc() {
		return originDc;
	}
	public void setOriginDc(String originDc) {
		this.originDc = originDc;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getSchemaId() {
		return schemaId;
	}
	public void setSchemaId(String schemaId) {
		this.schemaId = schemaId;
	}
	public String getProcessed() {
		return processed;
	}
	public void setProcessed(String processed) {
		this.processed = processed;
	}
	

}

package com.lcl.scs.dataextractengine.constants;

import static java.time.ZoneOffset.UTC;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;

/**
 * The Class DataExtractEngineConstants.
 */
public class DataExtractEngineConstants {
    /** The Constant DELIMITER. */
    public static final String DELIMITER = ",";

    /** The Constant CONTENT_TYPE_HEADER. */
    public static final String CONTENT_TYPE_HEADER = "Content-Type";
    
    /** The Constant CORRELATION_ID_HEADER. */
    public static final String CORRELATION_ID_HEADER = "X-Correlation-ID";

    /** The Constant REQUEST_HEADER_LOCALE. */
    public static final String REQUEST_HEADER_LOCALE = "locale";

    /** The Constant REQUEST_HEADER_USERNAME. */
    public static final String REQUEST_HEADER_USERNAME = "userName";

    /** The Constant DATE_FORMAT. */
    public static final String DATE_FORMAT = "yyyyMMdd_HHmmss";

	/** The Constant DATE_FORMAT. */
	public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";

    /** The Constant WHITE_SPACE. */
    public static final String WHITE_SPACE = "\\s";

    /** The Constant UNDER_SCORE. */
    public static final String UNDER_SCORE = "_";

    /** The Constant DOT_SEPARATOR. */
    public static final String DOT_SEPARATOR = ".";

    /** The Constant USERNAME. */
    public static final String USERNAME = "userName";

    /** The Constant LOGGING_TXN_ID. */
    public static final String LOGGING_CORRELATION_KEY = "correlId";

    /** The Constant DATE for query_param_value_type. */
    public static final String DATE = "DATE";

    /** The Constant CHAR. */
    public static final String CHAR = "CHAR";

    /** The Constant TIMESTAMP. */
    public static final String TIMESTAMP = "TIMESTAMP";
    
    public static final String INCREMENTAL_EXTRACT_TO_TIMESTAMP = "ICRM_TO_TS";

    public static final String INCREMENTAL_EXTRACT_FROM_TIMESTAMP = "ICRM_FROM_TS";

    /**
     * The min date value to be used as the starting date when it is not specified.
     */
    public static final Date MIN_DATE = Date.from(Instant.from(LocalDate.of(0, 1, 1).atStartOfDay(UTC)));
    


}

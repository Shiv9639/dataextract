package com.lcl.scs.dataextractengine.report.processor;

import java.util.function.Consumer;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.google.common.base.Predicate;
import com.lcl.scs.dataextractengine.report.domain.DataExtractCallBackResponse;

public abstract class DataExtractServicePostProcessor {
	
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${report.file.base.path}")
	private String filePath;

	Predicate<DataExtractCallBackResponse> isReponseValid = response -> (response != null
			&& response.getProcessedRecordCount() > 0 && response.isFileSysRptInd() && response.isPrcExecStatus());

	public Consumer<DataExtractCallBackResponse> process = response -> {
		if (isReponseValid.apply(response)) {
			processResponse(response);
		}
		else
		{
			logger.error("DataExtract CallBackResponse and Response from API didnot match");
		}
	};

	protected abstract void processResponse(DataExtractCallBackResponse response);

	Supplier<String> getDefaultFilePath = () -> {
		return filePath;
	};
}

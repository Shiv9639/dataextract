package com.lcl.scs.dataextractengine.domain;

import java.util.List;
import java.util.StringJoiner;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.lcl.scs.dataextractengine.util.CollectionName;

import io.swagger.v3.oas.annotations.media.Schema;


/**
 * Data extract request class.
 */

public class DataExtractRequest {

    /**
     * The report id.
     */
    @Schema(description = "Report id", required = true, example = "1234")
    @NotNull(message = "Report Id can not be Null or Empty")
    private Long reportId;

    /**
     * The pcs exec id.
     */
    @Schema(description = "Process execution id", required = true, example = "1234")
    @NotNull(message = "Pcs Exec Id can not be Null or Empty")
    private Long pcsExecId;

    /**
     * The query parameters.
     */
    @Schema(description = "List of query parameters to be considered for extraction")
    private List<QueryParameter> queryParameters;

    /**
     * The call back url.
     */
    @Schema(description = "Call back url for notifying the final extraction status", required = true)
    @NotEmpty(message = "CallBack URL can not be Null or Empty")
    private String callBackUrl;
    
    /**
     * The mongo collection name.
     */
    @Schema(description = "Collection name of mongo", required = false, example = "user")
    private CollectionName collectionName;
    
    /**
     * The update collection record from mongo if is it true
     */
    @Schema(description = "Need to update collection record?", required = false, example = "either true or false")
    private boolean updateRecord;
    
    /**
     * The collection record primary field name
     */
    @Schema(description = "Primary Field Name", required = false, example = "BB_ID")
    private String primaryFieldName;
    
    private boolean excludeReportHeaders;

	private String fileName;


    /**
     * Gets the report id.
     *
     * @return the  report id
     */
    public Long getReportId() {
        return reportId;
    }

    /**
     * Sets the report id.
     *
     * @param reportId the new report id
     */
    public void setReportId(Long reportId) {
        this.reportId = reportId;
    }

    /**
     * Gets the pcs exec id.
     *
     * @return the pcs exec id
     */
    public Long getPcsExecId() {
        return pcsExecId;
    }

    /**
     * Sets the pcs exec id.
     *
     * @param pcsExecId the new pcs exec id
     */
    public void setPcsExecId(Long pcsExecId) {
        this.pcsExecId = pcsExecId;
    }

    /**
     * Gets the query parameters.
     *
     * @return the query parameters
     */
    public List<QueryParameter> getQueryParameters() {
        return queryParameters;
    }

    /**
     * Sets the query parameters.
     *
     * @param queryParameters the new query parameters
     */
    public void setQueryParameters(List<QueryParameter> queryParameters) {
        this.queryParameters = queryParameters;
    }

    /**
     * Gets the call back url.
     *
     * @return the call back url
     */
    public String getCallBackUrl() {
        return callBackUrl;
    }

    /**
     * Sets the call back url.
     *
     * @param callBackUrl the new call back url
     */
    public void setCallBackUrl(String callBackUrl) {
        this.callBackUrl = callBackUrl;
    }


    @Override public String toString() {
        return new StringJoiner(", ", "DataExtractRequest{", "}")
            .add("reportId=" + reportId)
            .add("pcsExecId=" + pcsExecId)
            .add("queryParameters=" + queryParameters)
            .add("excludeReportHeaders=" + excludeReportHeaders)
            .add("callBackUrl='" + callBackUrl + "'")
            .toString();
    }

	public boolean isExcludeReportHeaders() {
		return excludeReportHeaders;
	}

	public void setExcludeReportHeaders(boolean excludeReportHeaders) {
		this.excludeReportHeaders = excludeReportHeaders;
	}

	public CollectionName getCollectionName() {
		return collectionName;
	}

	public void setCollectionName(CollectionName collectionName) {
		this.collectionName = collectionName;
	}

	public boolean isUpdateRecord() {
		return updateRecord;
	}

	public void setUpdateRecord(boolean updateRecord) {
		this.updateRecord = updateRecord;
	}

	public String getPrimaryFieldName() {
		return primaryFieldName;
	}

	public void setPrimaryFieldName(String primaryFieldName) {
		this.primaryFieldName = primaryFieldName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}	
}

package com.lcl.scs.dataextractengine.entity;

import java.util.Date;

import javax.persistence.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document("R10039")
public class R10039Events{
	
	@Id
	@Field("_id")
	private String id;
	@Field(name = "fileName")
	private String fileName;
	@Field(name = "content")
	private String content;
	@Field(name = "createdDate")
	private Date createdDate;
	
	public String getId() {
		return id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public String toString() {
		return "R10039Events [id=" + id + ", fileName=" + fileName + ", createdDate=" + createdDate + "]";
	}
	
}

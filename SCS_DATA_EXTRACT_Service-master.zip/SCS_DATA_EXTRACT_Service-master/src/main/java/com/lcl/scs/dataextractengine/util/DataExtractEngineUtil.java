package com.lcl.scs.dataextractengine.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import com.lcl.scs.dataextractengine.constants.DataExtractEngineConstants;

/**
 * The Class DataExtractEngineUtil.
 */
public enum DataExtractEngineUtil {
    INSTANCE;

    /**
     * Appends system date and time to the file.
     *
     * @param fileName the file name
     * @param format the format
     * @return the local file name
     */
    public String getLocalFileName(String fileName, String format) {
        fileName = fileName.replaceAll(DataExtractEngineConstants.WHITE_SPACE, DataExtractEngineConstants.UNDER_SCORE).toLowerCase();
        return fileName + DataExtractEngineConstants.UNDER_SCORE + getCurrentDateAndTimeString() + DataExtractEngineConstants.DOT_SEPARATOR + format;
    }

    /**
     * Returns current system date.
     *
     * @return date in number format
     */
    public String getCurrentDateAndTimeString() {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DataExtractEngineConstants.DATE_FORMAT);
        LocalDateTime date = LocalDateTime.now();
        return dateFormatter.format(date);
    }
    
    /**
     * Returns current system date.
     *
     * @return date in number format
     */
	public String getCurrentDateString() {
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DataExtractEngineConstants.DATE_FORMAT_YYYYMMDD);
		LocalDateTime date = LocalDateTime.now();
		return dateFormatter.format(date);
	}

	/**
	 * Returns current system date.
	 *
	 * @return date in number format
	 */
    public Date getCurrentDateAndTime() {
        return Calendar.getInstance().getTime();
    }

}

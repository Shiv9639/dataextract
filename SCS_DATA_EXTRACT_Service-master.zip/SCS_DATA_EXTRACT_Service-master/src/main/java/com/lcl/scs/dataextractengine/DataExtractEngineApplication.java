package com.lcl.scs.dataextractengine;

import java.util.TimeZone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;


/**
 * The Class DataExtractEngineApplication.
 */
@SpringBootApplication(scanBasePackages = {"com.lcl.scs.dataextractengine"})
@EnableAutoConfiguration
@EnableScheduling
public class DataExtractEngineApplication {

    /**
     * * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
    	//System.setProperty("user.timezone", "UTC");
    	TimeZone timeZone = TimeZone.getTimeZone("America/New_York");
        TimeZone.setDefault(timeZone);
        SpringApplication.run(DataExtractEngineApplication.class, args);
    }

}
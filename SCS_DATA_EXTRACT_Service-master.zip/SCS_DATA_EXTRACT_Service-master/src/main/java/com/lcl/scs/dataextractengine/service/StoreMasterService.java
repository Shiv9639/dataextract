package com.lcl.scs.dataextractengine.service;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;

@Service
public class StoreMasterService {
	@Autowired
	private MongoClient mongoClient;

	@Value("${spring.data.mongodb.database}")
	private String database;

	public String getInternalLocationNumber(String storeNumber) {
		MongoCollection<Document> collection = mongoClient.getDatabase(database).getCollection("StoreMaster");
		Document document = collection.find(Filters.eq("_id.externalLocationNumber", storeNumber)).first();
		Document idDocument = (Document) document.get("_id");
		return idDocument.get("internalLocationNumber").toString();
	}

}

package com.lcl.scs.dataextractengine.report.postprocess.api;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.lcl.scs.dataextractengine.report.domain.DataExtractCallBackResponse;
import com.lcl.scs.dataextractengine.report.processor.CarrierMasterListReportPostProcessor;
import com.lcl.scs.dataextractengine.report.processor.DCReportPostProcessing;
import com.lcl.scs.dataextractengine.report.processor.NetworkScheduleDCStoreMapReportPostProcessor;

@RestController
public class ReportExtractPostProcessApiController implements ReportExtractPostProcessApi {

	private Logger logger = LoggerFactory.getLogger(getClass());

	/** The thread pool task executor. */
	@Autowired
	private Executor taskExecutor;

	@Autowired
	private DCReportPostProcessing dcReportPostProcessing;
	
	@Autowired
	private CarrierMasterListReportPostProcessor carrierMasterListReportPostProcessor;
	
	@Autowired
	private NetworkScheduleDCStoreMapReportPostProcessor networkScheduleDCStoreMapReportPostProcessor;
	

	@Override
	public ResponseEntity<String> dcReportPostProcess(String correlationId,
			DataExtractCallBackResponse callBackResponse) {
		try {
			CompletableFuture.runAsync(() -> {
				logger.info("Started post processing for DC Report {} correlationId : {} ",
						callBackResponse.getReportId(), correlationId);
				dcReportPostProcessing.process.accept(callBackResponse);
				logger.info("Ended async execution for report id: {} correlationId : {} ", callBackResponse.getReportId(), correlationId);
			}, taskExecutor);
		} catch (Exception ex) {
			logger.error("Exception in getExtractGeneration()", ex);
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.info("In processExtractGeneration");
		return new ResponseEntity<String>(HttpStatus.ACCEPTED);

	}

	@Override
	public ResponseEntity<String> carrierMasterListReportPostProcess(String correlationId,
			DataExtractCallBackResponse callBackResponse) {
		try {
			CompletableFuture.runAsync(() -> {
				logger.info("Started post processing for carrier Master list Report {} correlationId : {} ",
						callBackResponse.getReportId(), correlationId );
				carrierMasterListReportPostProcessor.process.accept(callBackResponse);
				logger.info("Ended async execution for report id: {} correlationId : {} ", callBackResponse.getReportId(), correlationId);
			}, taskExecutor);
		} catch (Exception ex) {
			logger.error("Exception in getExtractGeneration()", ex);
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.info("In processExtractGeneration");
		return new ResponseEntity<String>(HttpStatus.ACCEPTED);
	}

	@Override
	public ResponseEntity<String> networkScheduleDCStoreMapPostProcess(String correlationId,
			DataExtractCallBackResponse callBackResponse) {
		try {
			CompletableFuture.runAsync(() -> {
				logger.info(
						"Started post processing for network schedule DC to store mapping Report {} correlationId : {} ",
						callBackResponse.getReportId(), correlationId);
				networkScheduleDCStoreMapReportPostProcessor.process.accept(callBackResponse);
				logger.info("Ended async execution for report id: {} correlationId : {} ",
						callBackResponse.getReportId(), correlationId);
			}, taskExecutor);
		} catch (Exception ex) {
			logger.error("Exception in getExtractGeneration()", ex);
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		logger.info("In processExtractGeneration");
		return new ResponseEntity<String>(HttpStatus.ACCEPTED);
	}
}
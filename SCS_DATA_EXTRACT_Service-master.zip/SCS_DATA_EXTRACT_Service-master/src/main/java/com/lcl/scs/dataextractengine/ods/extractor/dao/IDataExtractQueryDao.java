package com.lcl.scs.dataextractengine.ods.extractor.dao;

import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.lcl.scs.dataextractengine.domain.QueryResult;

public interface IDataExtractQueryDao {

	public int executeExtractQuerySql(String extractQuerySql, SqlParameterSource namedParameters,
			QueryResult queryResult, boolean excludeReportHeaders);

}

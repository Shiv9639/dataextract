package com.lcl.scs.dataextractengine.report.processor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.lcl.scs.dataextractengine.report.constants.DataExtractReportIdConstant;
import com.lcl.scs.dataextractengine.report.constants.PostBackServiceConstants;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

@Service
public class NetworkScheduleDCStoreMapReportPreProcessor extends DataExtractServicePreProcessor {

	private static final String DC_TO_STORE_MAPPING_REPORTNAME = "dctostoremapping";
	private static final String REPORT_EXTENSION = ".csv";
	public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";

	@Scheduled(cron = "0 15 1 * * ?")
	@SchedulerLock(name = "NetworkScheduleDCStoreMapReportPreProcessor", lockAtLeastFor = "PT5M", lockAtMostFor = "PT5M")
	public void submitReport() {
		invokeDataExtractEngine.accept(DataExtractReportIdConstant.NETWORK_SCHEDULE_DC_STORE_REPORT,
				generateReportName());
	}

	@Override
	protected String getAbsolutePathForReportPostProcess() {
		return PostBackServiceConstants.NETWORK_SCHEDULE_DC_STORE_REPORT_POST_BACK_URL;
	}

	// we are generating report name specifically, the same report name is used to
	// in data extract scheduler to load data from goldengate to ODS.
	private String generateReportName() {
		return DC_TO_STORE_MAPPING_REPORTNAME.concat(getCurrentDateString()).concat(REPORT_EXTENSION);
	}

	/**
	 * Returns current system date.
	 *
	 * @return date in number format
	 */
	public String getCurrentDateString() {
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DATE_FORMAT_YYYYMMDD);
		LocalDateTime date = LocalDateTime.now();
		return dateFormatter.format(date);
	}
}

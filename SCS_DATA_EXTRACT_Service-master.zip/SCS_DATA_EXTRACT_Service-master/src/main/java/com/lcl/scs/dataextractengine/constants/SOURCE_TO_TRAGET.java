package com.lcl.scs.dataextractengine.constants;

public enum SOURCE_TO_TRAGET {

	ODS_DB_TO_CSV, ODS_DB_TO_MONGO_DB, GOLDEN_GATE_TO_CSV, GOLDEN_GATE_TO_MONGO_DB, DC022_DB_TO_MONGO_DB, DC028_DB_TO_MONGO_DB

}

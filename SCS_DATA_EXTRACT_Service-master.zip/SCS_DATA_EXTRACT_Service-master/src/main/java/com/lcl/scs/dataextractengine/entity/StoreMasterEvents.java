package com.lcl.scs.dataextractengine.entity;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document("StoreMaster")
public class StoreMasterEvents {
	@Field(name = "_id")
	private ID id = new ID();

	public static class ID {
		@Field(name = "externalLocationNumber")
		private String SDMStoreNumber;
		@Field(name = "internalLocationNumber")
		private String storeNumber;

		public String getSDMStoreNumber() {
			return SDMStoreNumber;
		}

		public void setSDMStoreNumber(String sDMStoreNumber) {
			SDMStoreNumber = sDMStoreNumber;
		}

		public String getStoreNumber() {
			return storeNumber;
		}

		public void setStoreNumber(String storeNumber) {
			this.storeNumber = storeNumber;
		}
	}

	public ID getId() {
		return id;
	}

	public void setId(ID id) {
		this.id = id;
	}
}
package com.lcl.scs.dataextractengine.interceptor;

import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.lcl.scs.dataextractengine.constants.DataExtractEngineConstants;

@Component
public class DataExtractServiceLoggingInterceptor  extends HandlerInterceptorAdapter {
	 private static final Logger logger = LoggerFactory.getLogger(DataExtractServiceLoggingInterceptor.class);
	 
	 @Override
	    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		 setCorrelationId(request);
	        logger.info("[TxnId: {}, Method: {}, URI: {}]",
	                new Object[] {MDC.get(DataExtractEngineConstants.LOGGING_CORRELATION_KEY), request.getRemoteAddr(), request.getMethod(), request.getRequestURI()});
	        return true;
	    }
	 
	    @Override
	    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception exception) throws Exception {
	        if (logger.isErrorEnabled() && exception != null) {
	            String exceptionMessage = exception.getMessage();
	            String methodName = request.getMethod();
	            logger.error("Exception occurred in {}, Message: {}", new Object[] {methodName, exceptionMessage, exception});
	        }
	    }
	    
	    /**
	     * Method to set the transactionID passed in the request. If not present, auto-generate the id
	     * 
	     * @param request the incoming servlet request
	     */
		private void setCorrelationId(HttpServletRequest request) {
			String correlId = request.getHeader(DataExtractEngineConstants.CORRELATION_ID_HEADER);
			if (StringUtils.isBlank(correlId)) {
				correlId = UUID.randomUUID().toString();
			}
			MDC.put(DataExtractEngineConstants.LOGGING_CORRELATION_KEY, correlId);
		}
	    
	 
}

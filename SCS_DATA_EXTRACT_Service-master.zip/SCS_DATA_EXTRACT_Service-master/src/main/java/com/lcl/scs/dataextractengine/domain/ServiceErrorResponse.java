package com.lcl.scs.dataextractengine.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.Serializable;
import java.util.List;

/**
 * The Class ServiceErrorResponse.
 */
@JsonPropertyOrder({"messages"})
public class ServiceErrorResponse implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The message. */
    private List<ErrorMessage> message;

    /**
     * Gets the message.
     *
     * @return the message
     */
    @JsonProperty("messages")
    public List<ErrorMessage> getMessage() {
        return message;
    }

    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(List<ErrorMessage> message) {
        this.message = message;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ServiceErrorResponse [message=" + message + "]";
    }



    /**
     * The Class ValidationError.
     */
    @JsonPropertyOrder({"code", "description"})
    public static class ErrorMessage {

        /** The code. */
        private String code;

        /** The description. */
        private String description;

        /**
         * Gets the code.
         *
         * @return the code
         */
        @JsonProperty("code")
        public String getCode() {
            return code;
        }

        /**
         * Sets the code.
         *
         * @param code the new code
         */
        public void setCode(String code) {
            this.code = code;
        }

        /**
         * Gets the description.
         *
         * @return the description
         */
        @JsonProperty("description")
        public String getDescription() {
            return description;
        }

        /**
         * Sets the description.
         *
         * @param description the new description
         */
        public void setDescription(String description) {
            this.description = description;
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.lang.Object#toString()
         */
        @Override
        public String toString() {
            return "ValidationError [code=" + code + ", description=" + description + "]";
        }
    }
}

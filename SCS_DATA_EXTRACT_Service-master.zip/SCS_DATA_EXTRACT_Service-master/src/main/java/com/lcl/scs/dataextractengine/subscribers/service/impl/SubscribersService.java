package com.lcl.scs.dataextractengine.subscribers.service.impl;

import java.util.List;

import com.lcl.scs.dataextractengine.subscribers.model.Subscribers;

public interface SubscribersService {
	
	Subscribers findByName(String name);
	List<Subscribers> findBySubscribername(String subscribername);
	Subscribers save(Subscribers subscribers);
	

}
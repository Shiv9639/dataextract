package com.lcl.scs.dataextractengine.sftp.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.common.io.ByteStreams;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.lcl.scs.dataextractengine.gcp.GCPServiceFactory;
import com.lcl.scs.dataextractengine.report.constants.ReportConstants;
import com.lcl.scs.dataextractengine.sftp.TransferType;
import com.lcl.scs.dataextractengine.sftp.document.SftpConnectionProperties;
import com.lcl.scs.dataextractengine.sftp.exception.SftpCoreException;
import com.lcl.scs.dataextractengine.sftp.model.FileData;
import com.lcl.scs.dataextractengine.sftp.repository.SftpConnectionPropertiesRepository;
import com.lcl.scs.dataextractengine.sftp.secure.SecurePassword;
import com.lcl.scs.dataextractengine.util.logging.LoggingUtilities;

@Service
public class SftpServiceImpl implements SftpService {

	@Autowired
	private SftpConnectionPropertiesRepository sftpConnectionPropertiesRepository;

	@Autowired
	private GCPServiceFactory gcpServiceFactory;

	@Autowired
	private FileUtilities fileUtilities;

	@Value("${sftpserver.file.base.path}")
	private String filePath;

	@Value("${loblaw.appian.base.url}")
	private String appianBaseUrl;

	@Value("${loblaw.appian.api.key}")
	private String apiKey;

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Override
	public boolean transfer(Long sftpConnectionId, TransferType transferType, String appianEndpoint)
			throws JSchException, SftpCoreException, IOException, SftpException {
		switch (transferType) {
		case SFTP_TO_GCP:
			FileData fileData = getFileFromSFTPServer(sftpConnectionId);
			String fileName = getFileName(fileData.getName());
			boolean isDone = gcpServiceFactory.writeToGcs(fileName, filePath, fileData.getContent());
			if (isDone) {
				logger.info("SFTP TO GCP file {} loaded successfully ", fileName);
				return true;
			} else {
				return false;
			}
		case SFTP_TO_GCP_TO_APPIAN:
			FileData sftpFileData = getFileFromSFTPServer(sftpConnectionId);
			String sftpFileName = getFileName(sftpFileData.getName());
			boolean isProcessed = gcpServiceFactory.writeToGcs(sftpFileName, filePath, sftpFileData.getContent());
			if (isProcessed) {
				logger.info("SFTP TO GCP file {} loaded successfully ", sftpFileName);

				// Pushing data to APPIAN
//				datPushToAppian(sftpFileData, appianEndpoint);
				
				return true;
			} else {
				return false;
			}

		default:
			logger.warn("Invalid transferType");
			return false;
		}
	}

	@Override
	public boolean transfer(Long sftpConnectionId, TransferType transferType, String appianEndpoint,List<String> headers, int index,
			String headerName) throws JSchException, SftpCoreException, IOException, SftpException {
		if (transferType.equals(TransferType.SFTP_TO_GCP_TO_APPIAN)) {
			FileData fileData = getFileFromSFTPServer(sftpConnectionId);
			String fileName = getFileName(fileData.getName());
			byte[] fileBytes = fileUtilities.doFileChange(fileData.getContent(), headers, index, headerName);
			boolean isDone = gcpServiceFactory.writeToGcs(fileName, filePath, fileBytes);
			if (isDone) {
				logger.info("SFTP TO GCP file {} loaded successfully ", fileName);
				datPushToAppian(fileBytes, appianEndpoint, fileName);
				return true;
			} else {
				return false;
			}
			
		} else if (transferType.equals(TransferType.SFTP_TO_GCP)) {
			return true;
		} else {
			logger.warn("Invalid transferType");
			return false;
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public FileData getFileFromSFTPServer(Long sftpConnectionId) throws JSchException, SftpException {
		Optional<SftpConnectionProperties> sftpConnectionProperties = sftpConnectionPropertiesRepository
				.findByConnectionId(sftpConnectionId);
		if (sftpConnectionProperties.isPresent()) {
			SftpConnectionProperties properties = sftpConnectionProperties.get();
			ChannelSftp channelSftp = null;
			try {
				channelSftp = createChannelSftp(properties);
				channelSftp.cd(properties.getRemotePath());
				Vector<ChannelSftp.LsEntry> list = channelSftp.ls(".");
				ChannelSftp.LsEntry file = list.stream()
						.max(Comparator.comparingInt(entry -> entry.getAttrs().getMTime())).get();
				String fileName = file.getFilename();
				InputStream inputStream = channelSftp.get(fileName);
				return new FileData(fileName, ByteStreams.toByteArray(inputStream));
			} catch (IOException e) {
				LoggingUtilities.generateErrorLog(e.getMessage());
			} finally {
				disconnectChannelSftp(channelSftp);
			}
		} else {
			throw new SftpCoreException(
					String.format("No such SFTP configuration found for sftpConnectionId : %d ", sftpConnectionId));
		}
		return null;
	}

	/**
	 * Prepare SFTP Channel.
	 * 
	 * @param properties
	 * @return
	 * @throws JSchException
	 */
	private ChannelSftp createChannelSftp(SftpConnectionProperties properties) throws JSchException {
		JSch jSch = new JSch();
		Session session = jSch.getSession(properties.getUserId(), properties.getHost(), properties.getPort());
		session.setConfig("StrictHostKeyChecking", "no");
		session.setPassword(SecurePassword.decrypt(properties.getPassword()));
		session.connect(properties.getSessionTimeout());
		Channel channel = session.openChannel("sftp");
		channel.connect(properties.getChannelTimeout());
		return (ChannelSftp) channel;
	}

	/**
	 * Close SFTP open connection.
	 * 
	 * @param channelSftp
	 */
	private void disconnectChannelSftp(ChannelSftp channelSftp) {
		try {
			if (channelSftp == null)
				return;
			if (channelSftp.isConnected())
				channelSftp.disconnect();
			if (channelSftp.getSession() != null)
				channelSftp.getSession().disconnect();
		} catch (Exception ex) {
			logger.error("SFTP disconnect error", ex);
		}
	}

	/**
	 * Merge extension along with file.
	 * 
	 * @param fileName
	 * @return
	 */
	private String getFileName(String fileName) {
		if (fileName != null) {
			int lastIndexOf = fileName.lastIndexOf(".");
			if (lastIndexOf == -1) {
				return fileName + ".csv";
			}
		}
		return fileName;
	}

	private void datPushToAppian(byte[] fileData, String appianEndpoint, String fileName) throws IOException {
		StringBuilder appianUrl = new StringBuilder(appianBaseUrl).append(appianEndpoint);
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set(ReportConstants.APPIAN_API_KEY_HEADER, apiKey);
		headers.set(ReportConstants.APPIAN_DOCUMENT_NAME_KEY_HEADER, fileName);
		headers.setContentType(new MediaType("text", "csv"));
		HttpEntity<byte[]> requestEntity = new HttpEntity<byte[]>(fileData,
				headers);
		ResponseEntity<String> appianresponse = restTemplate.postForEntity(appianUrl.toString(), requestEntity,
				String.class);
		if (appianresponse.getStatusCode().is2xxSuccessful()) {
			logger.info("Pushing to Appian was successful :  the Response status code is {}",
					appianresponse.getStatusCode());
		} else {
			logger.error("Pushing to Appian was not successful : the Response status code is {}",
					appianresponse.getStatusCode());
		}
	}
}

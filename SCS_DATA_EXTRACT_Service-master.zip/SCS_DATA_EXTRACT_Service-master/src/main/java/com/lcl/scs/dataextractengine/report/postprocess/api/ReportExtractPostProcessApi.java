package com.lcl.scs.dataextractengine.report.postprocess.api;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.lcl.scs.dataextractengine.report.constants.PostBackServiceConstants;
import com.lcl.scs.dataextractengine.report.domain.DataExtractCallBackResponse;

public interface ReportExtractPostProcessApi {

	@PostMapping(value = PostBackServiceConstants.DC_REPORT_POST_BACK_URL, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> dcReportPostProcess(
			@RequestHeader("X-Correlation-ID") String correlationId,
			 @RequestBody DataExtractCallBackResponse callBackResponse);
	
	@PostMapping(value = PostBackServiceConstants.CARRIER_MASTER_LIST_REPORT_POST_BACK_URL, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> carrierMasterListReportPostProcess(
			@RequestHeader("X-Correlation-ID") String correlationId,
			 @RequestBody DataExtractCallBackResponse callBackResponse);

	@PostMapping(value = PostBackServiceConstants.NETWORK_SCHEDULE_DC_STORE_REPORT_POST_BACK_URL, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> networkScheduleDCStoreMapPostProcess(
			@RequestHeader("X-Correlation-ID") String correlationId,
			@RequestBody DataExtractCallBackResponse callBackResponse);

}

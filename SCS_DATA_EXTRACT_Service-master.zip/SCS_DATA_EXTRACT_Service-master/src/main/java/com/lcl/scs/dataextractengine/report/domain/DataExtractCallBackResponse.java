package com.lcl.scs.dataextractengine.report.domain;

public class DataExtractCallBackResponse {

	private Long reportId;

	/**
	 * The execution status sent in callback.
	 */
	private boolean prcExecStatus;

	/**
	 * The file name.
	 */
	private String fileName;

	/**
	 * The file sys rpt ind.
	 */
	private boolean fileSysRptInd;

	/**
	 * The processed record count.
	 */
	private int processedRecordCount;

	public Long getReportId() {
		return reportId;
	}

	public void setReportId(Long reportId) {
		this.reportId = reportId;
	}

	public boolean isPrcExecStatus() {
		return prcExecStatus;
	}

	public void setPrcExecStatus(boolean prcExecStatus) {
		this.prcExecStatus = prcExecStatus;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public boolean isFileSysRptInd() {
		return fileSysRptInd;
	}

	public void setFileSysRptInd(boolean fileSysRptInd) {
		this.fileSysRptInd = fileSysRptInd;
	}

	public int getProcessedRecordCount() {
		return processedRecordCount;
	}

	public void setProcessedRecordCount(int processedRecordCount) {
		this.processedRecordCount = processedRecordCount;
	}

}

package com.lcl.scs.dataextractengine.ATSEDI214.scheduler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.lcl.scs.dataextractengine.domain.DeleteRecordRequest;
import com.lcl.scs.dataextractengine.processor.DataExtractsGenerationMongoDBProcessor;
import com.lcl.scs.dataextractengine.util.CollectionName;

@Service
public class ATSPurgingDataExtractScheduler {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	DataExtractsGenerationMongoDBProcessor dataExtractsGenerationMongoDBProcessor;
	
    //runs at 12:30 am
	@Scheduled(cron = "0 30 0 * * ?")
	public void deleteATSMongoRecords() {
		DeleteRecordRequest deleteRecordRequest = new DeleteRecordRequest();
		deleteRecordRequest.setCollectionName(CollectionName.ATSEDI214);
		deleteRecordRequest.setDeleteAll(Boolean.FALSE);
		deleteRecordRequest.setFieldName("Loading_Time");
		deleteRecordRequest.setNumberOfDays(14);
		dataExtractsGenerationMongoDBProcessor.processDeleteRecords(deleteRecordRequest);
	}

}

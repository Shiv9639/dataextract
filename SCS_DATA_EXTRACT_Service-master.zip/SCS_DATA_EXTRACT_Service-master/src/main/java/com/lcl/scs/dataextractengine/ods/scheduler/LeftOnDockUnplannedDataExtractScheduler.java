package com.lcl.scs.dataextractengine.ods.scheduler;

import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.processor.DataExtractsGenerationMongoDBProcessor;
import com.lcl.scs.dataextractengine.util.CollectionName;

@Service
public class LeftOnDockUnplannedDataExtractScheduler {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	DataExtractsGenerationMongoDBProcessor dataExtractsGenerationMongoDBProcessor;

	@Scheduled(cron = "0 */30 * ? * *")
	public void processDataExtractEngineMongoDb() {
		logger.info("ScheduledExecutorService getting started for LeftOnDockUnplanned");
		ScheduledExecutorService executor = Executors.newScheduledThreadPool(15);
		try {
			executor.schedule(new Runnable() {
				public void run() {
					DataExtractRequest dataExtractRequest = new DataExtractRequest();
					dataExtractRequest.setReportId(7L);
					dataExtractRequest.setCollectionName(CollectionName.UN_PLANNED_LEFT_ON_DOCK);
					dataExtractRequest.setUpdateRecord(Boolean.FALSE);
					dataExtractsGenerationMongoDBProcessor.processExtractGeneration(dataExtractRequest,
							UUID.randomUUID().toString());
					logger.info("Data Extraction to MongoDB is successful for : {}",
							dataExtractRequest.getCollectionName().getValue());
				}
			}, 0, TimeUnit.MILLISECONDS);
		} finally {
			executor.shutdown();
			try {
				if (!executor.awaitTermination(5, TimeUnit.MINUTES)) {
					executor.shutdownNow();
				}
			} catch (InterruptedException e) {
				executor.shutdownNow();
				logger.error(e.getMessage());
			}
			if (executor.isShutdown()) {
				logger.info("executor shutdown successfully for LeftOnDockUnplanned");
			}
		}
	}
}

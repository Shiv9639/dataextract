package com.lcl.scs.dataextractengine.gcp;

public class GCPFileDetails {

	private String filename;
	private String filePath;
	private String bucketName;
	private byte[] data;

	public GCPFileDetails() {
	}

	public GCPFileDetails(String filename) {
		super();
		this.filename = filename;
	}

	public GCPFileDetails(String filename, String filePath) {
		super();
		this.filename = filename;
		this.filePath = filePath;
	}

	public GCPFileDetails(String filename, String filePath, String bucketName) {
		super();
		this.filename = filename;
		this.filePath = filePath;
		this.bucketName = bucketName;
	}

	public GCPFileDetails(String filename, String filePath, String bucketName, byte[] data) {
		super();
		this.filename = filename;
		this.filePath = filePath;
		this.bucketName = bucketName;
		this.data = data;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getBucketName() {
		return bucketName;
	}

	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

}

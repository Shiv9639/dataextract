package com.lcl.scs.dataextractengine.sftp.service;

import java.io.IOException;
import java.util.List;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.lcl.scs.dataextractengine.sftp.TransferType;
import com.lcl.scs.dataextractengine.sftp.exception.SftpCoreException;
import com.lcl.scs.dataextractengine.sftp.model.FileData;

public interface SftpService {
	boolean transfer(Long sftpConnectionId, TransferType transferType, String appianEndpoint) throws JSchException, IOException, SftpException, SftpCoreException;
	boolean transfer(Long sftpConnectionId, TransferType transferType, String appianEndpoint,List<String> headers, int index, String headerName) throws JSchException, IOException, SftpException, SftpCoreException;
	FileData getFileFromSFTPServer(Long sftpConnectionId) throws JSchException, SftpException;
}

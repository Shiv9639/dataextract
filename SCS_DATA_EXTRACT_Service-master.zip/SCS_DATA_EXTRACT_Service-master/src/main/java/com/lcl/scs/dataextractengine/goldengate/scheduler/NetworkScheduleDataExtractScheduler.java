package com.lcl.scs.dataextractengine.goldengate.scheduler;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.domain.DeleteRecordRequest;
import com.lcl.scs.dataextractengine.domain.QueryParameter;
import com.lcl.scs.dataextractengine.gcp.GCPFileDetails;
import com.lcl.scs.dataextractengine.gcp.GCPServiceFactory;
import com.lcl.scs.dataextractengine.processor.DataExtractsGenerationMongoDBProcessor;
import com.lcl.scs.dataextractengine.util.CollectionName;
import com.lcl.scs.dataextractengine.util.DataExtractEngineUtil;
import com.mongodb.client.model.Filters;

@Service
public class NetworkScheduleDataExtractScheduler {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	private static final String DC_TO_STORE_MAPPING_REPORTNAME = "dctostoremapping";
	private static final String STORE_ID_PARAM_CODE = "store_id";
	private static final String STORE_ID_PARAM_TYPE_CODE = "String";

	@Autowired
	DataExtractsGenerationMongoDBProcessor dataExtractsGenerationMongoDBProcessor;

	@Autowired
	GCPServiceFactory gcpServiceFactory;

	@Value("${report.file.base.path}")
	private String filePath;

	@Scheduled(cron = "0 0 3 * * ?")
	// @Scheduled(cron = "0 0 0/1 * * ?")
	public void processDataExtractEngineMongoDb() throws IOException, InterruptedException {
		logger.info("Process started for Network scheduler");
		Set<String> storeList = getStoreList();
		if (!CollectionUtils.isEmpty(storeList)) {
			logger.info("Got the store list to run for Network schedule job");
			// lets run by 200 stores per iteration
			ExecutorService executor = Executors.newFixedThreadPool(200);
			// delete the collection before loading data
			logger.info("Network schedule collection deleted successfully. Started data dumping from golden gate");
			List<Callable<String>> callableTasks = new ArrayList<>();
			storeList.forEach(storeId -> {
				Callable<String> callableTask = () -> {
					deleteCollection(storeId);
					logger.info("Deleting the Network schedule for StoreId {} : ", storeId);
					DataExtractRequest dataExtractRequest = new DataExtractRequest();
					QueryParameter param = new QueryParameter();
					param.setQueryParmCode(STORE_ID_PARAM_CODE);
					param.setQueryParmValue(storeId);
					param.setQueryParmValueTypeCode(STORE_ID_PARAM_TYPE_CODE);
					dataExtractRequest.setReportId(3L);
					dataExtractRequest.setCollectionName(CollectionName.NETWORK_SCHEDULE);
					dataExtractRequest.setUpdateRecord(Boolean.FALSE);
					dataExtractRequest.setQueryParameters(Arrays.asList(param));
					dataExtractsGenerationMongoDBProcessor.processExtractGeneration(dataExtractRequest,
							UUID.randomUUID().toString());
					logger.info("Network schedule collection updated successfully, for the store {} :", storeId);
					return "done execution";
				};
				callableTasks.add(callableTask);
			});
			executor.invokeAll(callableTasks);
			executor.shutdown();
			try {
				if (!executor.awaitTermination(5, TimeUnit.MINUTES)) {
					executor.shutdownNow();
				}
			} catch (InterruptedException e) {
				executor.shutdownNow();
				logger.error(e.getMessage());
			}
			if (executor.isShutdown()) {
				logger.info("executor shutdown successfully for Network Scheduler");
			}
		} else {
			logger.info("Got the empty store list to run for Network schedule job. Not run for any store");
		}
	}

	private Set<String> getStoreList() throws IOException {
		GCPFileDetails fileDetails = readFilefromGCP();
		Set<String> storeList = new HashSet<String>();
		if (Objects.nonNull(fileDetails)) {
			CSVParser csvParser = new CSVParser(new InputStreamReader(new ByteArrayInputStream(fileDetails.getData())),
					CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
			Iterable<CSVRecord> csvRecords = csvParser.getRecords();
			storeList = StreamSupport.stream(csvRecords.spliterator(), false).map(csvRecord -> csvRecord.get(0))
					.collect(Collectors.toSet());
			csvParser.close();
		} else {
			logger.info("Store list file is not found in GCP. Golden gate Data extraction will not be continue. ");
		}
		return storeList;
	}

	private GCPFileDetails readFilefromGCP() {
		return gcpServiceFactory.getFilewithPath.apply(DC_TO_STORE_MAPPING_REPORTNAME
				.concat(DataExtractEngineUtil.INSTANCE.getCurrentDateString()).concat(".csv"), filePath);
	}

	public void deleteCollection(String storeId) {
		DeleteRecordRequest deleteRecordRequest = new DeleteRecordRequest();
		deleteRecordRequest.setCollectionName(CollectionName.NETWORK_SCHEDULE);
		Bson filter = Filters.eq("STORE_NUMBER", storeId);
		deleteRecordRequest.setFilter(filter);
		dataExtractsGenerationMongoDBProcessor.processDeleteRecords(deleteRecordRequest);
	}

}

package com.lcl.scs.dataextractengine.blackbox.dc022.extractor.dao;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.lcl.scs.dataextractengine.domain.QueryResult;
import com.lcl.scs.dataextractengine.ods.extractor.dao.IDataExtractQueryDao;

/**
 * The Class DataExtractQueryDao.
 */
@Component
public class DataExtractQueryDC022ToMongoDao implements IDataExtractQueryDao {

	/** The logger. */
	private Logger logger = LoggerFactory.getLogger(getClass());
	/** The named parameter jdbc template. */
	@Qualifier("namedJdbcdc022")
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Value("${com.jdbc.fetchSize}")
	private String fetchSize;

	/**
	 * Execute extract query sql.
	 *
	 * @param extractQuerySql the extract query sql
	 * @param namedParameters the named parameters
	 * @param file            the file
	 * @return int, if successful it will return >=0, in exception cases it will be
	 *         -1
	 */
	public int executeExtractQuerySql(String extractQuerySql, SqlParameterSource namedParameters,
			QueryResult queryResult, boolean excludeReportHeaders) {
		logger.info("Query execution getting started for {}", extractQuerySql);
		namedParameterJdbcTemplate.getJdbcTemplate().setFetchSize(Integer.valueOf(fetchSize));
		return namedParameterJdbcTemplate.query(extractQuerySql, namedParameters, new ResultSetExtractor<Integer>() {
			int resultsCount = 0;

			@Override
			public Integer extractData(final ResultSet rs) {
				try {
					queryResult.setResultsCount(resultsCount);
					logger.info("DataExtractQueryDao-> Processing Resultset for DC022");
					final ResultSetMetaData rsmd = rs.getMetaData();
					int columnCount = rsmd.getColumnCount();
					List<Document> documentList = new ArrayList<Document>();
					while (rs.next()) {
						resultsCount++;
						Document obj = new Document();
						for (int i = 1; i <= columnCount; i++) {
							final Object value = rs.getObject(i);
							obj.put(rsmd.getColumnName(i), value == null ? StringUtils.EMPTY : value.toString());
						}
						documentList.add(obj);
					}
					queryResult.setData(documentList);
					queryResult.setResultsCount(resultsCount);
					logger.info("Completed writing data into file for DC022");
				} catch (final SQLException ex) {
					resultsCount = -1;
					queryResult.setResultsCount(resultsCount);
					logger.error("Exception in executeExtractQuerySql()", ex);
				}
				logger.info("No. of records are being processed: {}", resultsCount);
				return resultsCount;
			}
		});
	}

}

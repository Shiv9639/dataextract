package com.lcl.scs.dataextractengine.subscribers.datacopier.scheduler;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.EntityBuilder;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.lcl.scs.dataextractengine.subscribers.constants.ApigeeConstants.APIGEE_TOKEN;
import com.lcl.scs.dataextractengine.subscribers.model.ApigeeToken;
import com.lcl.scs.dataextractengine.subscribers.model.Subscribers;
import com.lcl.scs.dataextractengine.util.logging.LoggingUtilities;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;


@Component
public class DataCopierScheduler {
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD HH:mm:ss");

	private static final int MAX_CONNECTION_VARIABLE = Integer.parseInt(System.getenv("MAX_CONNECTION"));
	private static final String ENCODE_RESPONSE_VARIABLE = System.getenv("ENCODE_RESPONSE");

	@Value("${spring.data.mongodb.uri}")
	private String mongodbURI;
	@Value("${spring.data.mongodb.database}")
	private String mongodbDatabase;
	@Autowired
	private com.lcl.scs.dataextractengine.subscribers.service.impl.SubscribersService subscribersService;

	private int LAST_RUN_TIME_BUFFER = 0;
	private String CONTENT_TYPE = "application/json";

	@Autowired
	private MongoClient mongoClient;

	private ApigeeToken token;

	
	@Scheduled(fixedDelay = 1000 * 60 * 1)
	public void copyData() {
		LoggingUtilities.generateInfoLog(dateFormat.format(new Date()) + ": Start copying all new data");

		Date tempTime = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		
		try {
			List<Subscribers> subscribersList = subscribersService.findBySubscribername("SCS-LE");
			for (Subscribers s : subscribersList) {
				try {
					if (s.getLastrun() == null)
						continue;

					Date lastRunTime = new Date();
					LoggingUtilities.generateInfoLog("Subscriber saved with last run null at : " + s.getLastrun());
					BasicDBObject query = new BasicDBObject();
					Calendar c = Calendar.getInstance();
					c.setTime(s.getLastrun());
					c.add(Calendar.SECOND, LAST_RUN_TIME_BUFFER);
//					{"Loading_Time": {"$gte": new Date("2021-08-30T00:00:00.000Z")}}

					Date previousRunTime = c.getTime();
					LoggingUtilities.generateInfoLog("Previous Run Time : " + previousRunTime);
					tempTime = new Date();
					
					LoggingUtilities.generateInfoLog("temp time : " + tempTime);

					query.put("Loading_Time",
							BasicDBObjectBuilder.start("$gte", previousRunTime).add("$lte", tempTime).get());
//					query.put("Loading_Time", new BasicDBObject("$gte", previousRunTime));
					

					LoggingUtilities.generateInfoLog("Query : " + query);

					MongoCollection<Document> inbound_collection = mongoClient.getDatabase(mongodbDatabase)
							.getCollection(s.getInboundcollection());
					
//					FindIterable<Document> documents= inbound_collection.find(and(gte("Loading_Time", previousRunTime), lte("Loading_Time",tempTime)));
					//LoggingUtilities.generateInfoLog("Number of Documents : " + inbound_collection.countDocuments());
//					
					FindIterable<Document> documents = inbound_collection.find(query).sort(new BasicDBObject("_id", 1));

					
					token = getApigeeToken();
					Date initialTime = new Date();

					ExecutorService taskExecutor = Executors.newFixedThreadPool(MAX_CONNECTION_VARIABLE);
					for (Document doc : documents) {
					
							//LoggingUtilities.generateInfoLog("Document : " + doc);
							Date realTime = new Date();

							if (getTimeDifference(realTime, initialTime) > 15) { // generate new token every 15 minute
								LoggingUtilities.generateInfoLog("Apigee Token Expired");
								token = getApigeeToken();
								initialTime = new Date();
							}

							taskExecutor.execute(new Runnable() {
								@Override
								public void run() {
									try {
										if (ENCODE_RESPONSE_VARIABLE.equals("Y")) {
											
											LoggingUtilities.generateInfoLog(
													"Processing and encoding "+ s.getInboundcollection()+" collection payload with document _id "
															+ doc.get("_id"));
											postDocument(s.getOutboundcollection(), encodeJson(doc,s.getInboundcollection()),
													s.getOutboundEndpoint(), token);
										} else {
											LoggingUtilities.generateInfoLog(
													"Processing and encoding "+ s.getInboundcollection()+" collection payload with document _id "
															+ doc.get("_id"));
											postDocument(s.getOutboundcollection(), doc.toJson(),
													s.getOutboundEndpoint(), token);
										}

									} catch (Exception e) {
										LoggingUtilities.generateInfoLog(
												"Process failed R9333 collection payload with document _id "
														+ doc.get("_id"));
										e.printStackTrace();
									}
								}

							});
						}

					
					taskExecutor.shutdown();
					taskExecutor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);

				} catch (Exception e) {
//					s.setStatus("Stopped");
//					s.setLastrun(tempTime);
//					subscribersService.save(s);
					LoggingUtilities.generateErrorLog("Payload failed to process ");
					e.printStackTrace();
				}
				s.setStatus("Stopped");
				s.setLastrun(tempTime);
				subscribersService.save(s);
			}
		} catch (Exception ex) {
			LoggingUtilities.generateErrorLog("Failed to copy data! " + ex.getMessage());
			ex.printStackTrace();
		}

		LoggingUtilities.generateInfoLog(dateFormat.format(new Date()) + ": Finish coping all new data");

	}

	public int getTimeDifference(Date realTime, Date initialTime) {
		Date diff = new Date(realTime.getTime() - initialTime.getTime());
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(diff);
		return calendar.get(Calendar.MINUTE);
	}

	public String encodeJson(Document docu, String inboundCollection) throws Exception, ParseException {	
		Document temp;
		switch(inboundCollection) {
		  case "R9333":
			  temp = (Document) docu.get("NS1:SapOrders05Zorders0501");
			  temp.remove("xmlns:NS1");
		    break;
		  case "R9341":
			   temp = (Document) docu.get("NS1:SapDelvry07Zdelvry0703");
			  temp.remove("xmlns:NS1");
		    break;
		 
		}
		String obj = docu.toJson();
		String encodedString = "";

		if (obj.startsWith("{{")) {
			encodedString = obj.replaceFirst("{{", "{").replace(";", "Ow==").replace("+", "Kw==").replace("*", "Kg==")
					.replace("@", "QA==").replace("/", "Lw==").replace("\\\"\"", "XA==\"").replace("\\", "XA==")
					.replace("&", "Jq==").replace("(", "KA==").replace(")", "KQ==").replace("<", "PA==")
					.replace(">", "Pq==").replace("^", "Xg==");

			if (obj.endsWith("}}")) {
				encodedString = encodedString.substring(0, encodedString.length() - 1);
			}
		}

		else {
			encodedString = obj.replace(";", "Ow==").replace("+", "Kw==").replace("*", "Kg==").replace("@", "QA==")
					.replace("/", "Lw==").replace("\\\"\"", "XA==\"").replace("\\", "XA==").replace("&", "Jq==")
					.replace("(", "KA==").replace(")", "KQ==").replace("<", "PA==").replace(">", "Pq==")
					.replace("^", "Xg==");

		}

		return (encodedString);
	}

	private ApigeeToken getApigeeToken() throws Exception {
		LoggingUtilities.generateInfoLog("Generating Apigee Token");
		ApigeeTokenServiceImpl tokenService = new ApigeeTokenServiceImpl(APIGEE_TOKEN.URL.getValue(),
				APIGEE_TOKEN.CLIENT_ID.getValue(), APIGEE_TOKEN.CLIENT_SECRET.getValue(),
				APIGEE_TOKEN.GRANT_TYPE.getValue(), APIGEE_TOKEN.SCOPE.getValue());

		return tokenService.getApigeeToken();
	}

	private void postDocument(String interfaceName, String body, String copyToURL, ApigeeToken token) throws Exception {
		try {
			HttpClient client = HttpClientBuilder.create().build();

			HttpPost post = new HttpPost(copyToURL);
			post.setHeader(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE);
			post.setHeader("interface", interfaceName);
			post.setHeader(HttpHeaders.AUTHORIZATION, token.getToken_type() + " " + token.getAccess_token());
			post.setEntity(EntityBuilder.create().setText(body).build());
			HttpResponse response = client.execute(post);
			int code = response.getStatusLine().getStatusCode();
			HttpEntity responseEntity = response.getEntity();
			String responseStr = EntityUtils.toString(responseEntity);

			LoggingUtilities.generateInfoLog("Response: " + responseStr);

			if (code != 200) {
				LoggingUtilities.generateInfoLog("LCT API Response: " + responseStr + " The response code is " + code);
				if (code == 401) {
					LoggingUtilities.generateInfoLog("Apigee Token Expired");
					token = getApigeeToken();
					post.setHeader(HttpHeaders.AUTHORIZATION, token.getToken_type() + " " + token.getAccess_token());
					HttpResponse responses = client.execute(post);
					HttpEntity responsesEntity = responses.getEntity();
					String responsesStr = EntityUtils.toString(responsesEntity);
					LoggingUtilities.generateInfoLog("Response: " + responsesStr);

				}
				// throw new Exception("Invalid Response from " + copyToURL);
			}

		} catch (Exception ex) {
			ex.getMessage();
		}
	}
}

package com.lcl.scs.dataextractengine.configuration;

import java.util.Properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * The Class ApplicationConfig.
 */
@Configuration
@EnableAsync
class ApplicationConfig {

    /**
     * Data extract engine property config.
     *
     * @return the properties
     */
    @Bean
    @ConfigurationProperties("com")
    public Properties dataExtractEnginePropertyConfig() {
        return new Properties();
    }

    /**
     * Thread pool task executor.
     *
     * @return Executor
     */
    @Bean(name = "taskExecutor")
    public ThreadPoolTaskExecutor taskExecutor() {
        final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(Integer.MAX_VALUE);
        executor.setQueueCapacity(Integer.MAX_VALUE);
        executor.setThreadNamePrefix("DataExtract-Engine-Thread-");
        executor.initialize();
        return executor;      
    }
    
	/*
	 * @Bean public ThreadPoolTaskScheduler taskScheduler (){
	 * ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
	 * taskScheduler.setPoolSize(Integer.MAX_VALUE); return taskScheduler; }
	 */
}

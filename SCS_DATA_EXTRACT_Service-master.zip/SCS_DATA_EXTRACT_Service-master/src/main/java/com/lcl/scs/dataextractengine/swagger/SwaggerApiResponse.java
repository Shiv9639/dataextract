package com.lcl.scs.dataextractengine.swagger;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation for the generic http responses and the descriptions.
 */
@Documented
@Retention(RUNTIME)
@Target(TYPE)
@ApiResponses(value = {@ApiResponse(responseCode = "405", description = "Method Not Supported", content = @Content(schema = @Schema(hidden = true))),
        @ApiResponse(responseCode = "404", description = "Requested resource not found", content = @Content(schema = @Schema(hidden = true))),
        @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(schema = @Schema(hidden = true)))})
public @interface SwaggerApiResponse {

}

package com.lcl.scs.dataextractengine.report.constants;

public class ReportConstants {

    public static final String CONTENT_TYPE_HEADER = "Content-Type";
    /** The Constant CORRELATION_ID_HEADER. */
    public static final String CORRELATION_ID_HEADER = "X-Correlation-ID";
    
    public static final String APPIAN_API_KEY_HEADER = "Appian-API-Key";
    public static final String APPIAN_DOCUMENT_NAME_KEY_HEADER = "Appian-Document-Name";
    
}

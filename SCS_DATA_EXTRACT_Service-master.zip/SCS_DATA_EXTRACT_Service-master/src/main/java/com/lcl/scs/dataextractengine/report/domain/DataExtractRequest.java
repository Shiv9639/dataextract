package com.lcl.scs.dataextractengine.report.domain;

import java.util.StringJoiner;

/**
 * Data extract request class.
 */

public class DataExtractRequest {

	private Long reportId;

	private Long pcsExecId;

	private String callBackUrl;
	
	private boolean excludeReportHeaders;

	private String fileName;

	/**
	 * Gets the report id.
	 *
	 * @return the report id
	 */
	public Long getReportId() {
		return reportId;
	}

	/**
	 * Sets the report id.
	 *
	 * @param reportId the new report id
	 */
	public void setReportId(Long reportId) {
		this.reportId = reportId;
	}

	/**
	 * Gets the pcs exec id.
	 *
	 * @return the pcs exec id
	 */
	public Long getPcsExecId() {
		return pcsExecId;
	}

	/**
	 * Sets the pcs exec id.
	 *
	 * @param pcsExecId the new pcs exec id
	 */
	public void setPcsExecId(Long pcsExecId) {
		this.pcsExecId = pcsExecId;
	}

	/**
	 * Gets the call back url.
	 *
	 * @return the call back url
	 */
	public String getCallBackUrl() {
		return callBackUrl;
	}

	/**
	 * Sets the call back url.
	 *
	 * @param callBackUrl the new call back url
	 */
	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}
	

	@Override
	public String toString() {
		return new StringJoiner(", ", "DataExtractRequest{", "}").add("reportId=" + reportId)
				.add("pcsExecId=" + pcsExecId).add("callBackUrl='" + callBackUrl + "'").toString();
	}

	public boolean isExcludeReportHeaders() {
		return excludeReportHeaders;
	}

	public void setExcludeReportHeaders(boolean excludeReportHeaders) {
		this.excludeReportHeaders = excludeReportHeaders;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}

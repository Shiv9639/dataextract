package com.lcl.scs.dataextractengine.sftp;

public enum TransferType {
	SFTP_TO_GCP, SFTP_TO_GCP_TO_APPIAN
}

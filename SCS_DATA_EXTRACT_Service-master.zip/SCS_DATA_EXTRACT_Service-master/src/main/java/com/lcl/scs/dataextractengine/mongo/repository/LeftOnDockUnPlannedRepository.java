package com.lcl.scs.dataextractengine.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.lcl.scs.dataextractengine.entity.LeftOnDockUnPlannedEvents;

public interface LeftOnDockUnPlannedRepository extends MongoRepository<LeftOnDockUnPlannedEvents, String> {
	
	List<LeftOnDockUnPlannedEvents> findByProcessed(String processed);
	List<LeftOnDockUnPlannedEvents> findByShpmId(String shpmId);

}

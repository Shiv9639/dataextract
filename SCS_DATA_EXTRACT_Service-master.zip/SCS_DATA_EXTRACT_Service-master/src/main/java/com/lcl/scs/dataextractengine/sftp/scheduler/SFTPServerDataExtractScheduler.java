package com.lcl.scs.dataextractengine.sftp.scheduler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.lcl.scs.dataextractengine.sftp.TransferType;
import com.lcl.scs.dataextractengine.sftp.exception.SftpCoreException;
import com.lcl.scs.dataextractengine.sftp.service.SftpService;

@Service
public class SFTPServerDataExtractScheduler {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private SftpService sftpService;
	
	@Value("${fedexserver.notifications}")
	private boolean fedexNotificationsFlag;
	
	private String sftpFedexEndpoint = "lcl-fedex-status-push";

//	@Scheduled(cron = "0 */3 * ? * *")
	@Scheduled(cron = "0 10 * ? * *")  //Runs for every 1 hr 10mins
	public void processDataExtractEngineGcp() {
		if(fedexNotificationsFlag == true)
		{
			try {
				List<String> headers = new ArrayList<>();
				headers.add("TRCK#");
				headers.add("SHIPD");
				headers.add("ESTDD");
				headers.add("ESTDT");
				headers.add("DELVD");
				headers.add("DELVT");
				headers.add("STATD");
				headers.add("STATC");
				headers.add("SCODE");
				headers.add("AINFO");
				sftpService.transfer(1L, TransferType.SFTP_TO_GCP_TO_APPIAN, sftpFedexEndpoint, headers, 3, "TOTE_ID");
			} catch (SftpCoreException | JSchException | IOException | SftpException e) {
				logger.error(e.getMessage());
			}
		}
	}
}

package com.lcl.scs.dataextractengine.domain;

public class QueryResult {

	private Object data;
	private int resultsCount;

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public int getResultsCount() {
		return resultsCount;
	}

	public void setResultsCount(int resultsCount) {
		this.resultsCount = resultsCount;
	}

}

package com.lcl.scs.dataextractengine.sftp.document;

import java.io.Serializable;
import java.util.StringJoiner;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * The report object contains useful information about the report entry.
 */
/**
 * @author ddonike
 *
 */
@Document("SFTP_CONNECTIONS")
public class SftpConnectionProperties implements Serializable {
	static final long serialVersionUID = 652677942889196986L;

	@Id
	private String id;
	
	/**
	 * BI_CONNECTION_ID.
	 */
	//@MongoId
	@Field("CONNECTION_ID")
	private Long connectionId;
	
	@Field("CONNECTION_NAME")
	private String connectionName;
	
	@Field("HOST")
	private String host;
	
	@Field("PORT")
    private Integer port;
	
	@Field("USERID")
    private String userId;
	
	@Field("PASSWORD")
    private String password;
	
	@Field("SESSION_TIMEOUT")
    private Integer sessionTimeout;
	
	@Field("CHANNEL_TIMEOUT")
    private Integer channelTimeout;
	
	@Field("REMOTE_PATH")
    private String remotePath;
	
	//Getters and Setters
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getConnectionId() {
		return connectionId;
	}

	public void setConnectionId(Long connectionId) {
		this.connectionId = connectionId;
	}

	public String getConnectionName() {
		return connectionName;
	}

	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getSessionTimeout() {
		return sessionTimeout;
	}

	public void setSessionTimeout(Integer sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}

	public Integer getChannelTimeout() {
		return channelTimeout;
	}

	public void setChannelTimeout(Integer channelTimeout) {
		this.channelTimeout = channelTimeout;
	}

	public String getRemotePath() {
		return remotePath;
	}

	public void setRemotePath(String remotePath) {
		this.remotePath = remotePath;
	}

	@Override
	public String toString() {
		return new StringJoiner(",", "Connection{", "}").add("connectionId=" + connectionId).add("userId='" + userId + "'")
				.add("remotePath=" + remotePath).toString();
	}
}

package com.lcl.scs.dataextractengine.processor;

import static com.lcl.scs.dataextractengine.constants.DataExtractEngineConstants.INCREMENTAL_EXTRACT_FROM_TIMESTAMP;
import static com.lcl.scs.dataextractengine.constants.DataExtractEngineConstants.INCREMENTAL_EXTRACT_TO_TIMESTAMP;
import static com.lcl.scs.dataextractengine.constants.DataExtractEngineConstants.MIN_DATE;
import static java.time.ZoneOffset.UTC;

import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.time.StopWatch;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.lcl.scs.dataextractengine.blackbox.dc022.extractor.dao.DataExtractQueryDC022ToMongoDao;
import com.lcl.scs.dataextractengine.blackbox.dc028.extractor.dao.DataExtractQueryDC028ToMongoDao;
import com.lcl.scs.dataextractengine.constants.DataExtractEngineConstants;
import com.lcl.scs.dataextractengine.constants.SOURCE_TO_TRAGET;
import com.lcl.scs.dataextractengine.document.Report;
import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.domain.QueryParameter;
import com.lcl.scs.dataextractengine.domain.QueryResult;
import com.lcl.scs.dataextractengine.goldengate.extractor.dao.DataExtractQueryGoldenGateToCSVDao;
import com.lcl.scs.dataextractengine.goldengate.extractor.dao.DataExtractQueryGoldenGateToMongoDao;
import com.lcl.scs.dataextractengine.mongo.repository.LeftOnDockUnPlannedRepository;
import com.lcl.scs.dataextractengine.mongo.repository.ReportMongoRepository;
import com.lcl.scs.dataextractengine.ods.extractor.dao.DataExtractQueryDao;
import com.lcl.scs.dataextractengine.ods.extractor.dao.DataExtractQueryODSToMongoDao;
import com.lcl.scs.dataextractengine.ods.extractor.dao.IDataExtractQueryDao;
import com.lcl.scs.dataextractengine.util.DataExtractEngineUtil;

import oracle.jdbc.OracleTypes;

@Component
public class DataExtractGenerationProcessor {

	/**
	 * The data extract query dao.
	 */
	@Autowired
	private DataExtractQueryDao dataExtractQueryDao;

	@Autowired
	private DataExtractQueryGoldenGateToMongoDao dataExtractQueryGoldenGateToMongoDao;

	@Autowired
	private DataExtractQueryGoldenGateToCSVDao dataExtractQueryGoldenGateToCSVDao;

	@Autowired
	private DataExtractQueryDC028ToMongoDao dataExtractQueryDC028ToMongoDao;

	@Autowired
	private DataExtractQueryDC022ToMongoDao dataExtractQueryDC022ToMongoDao;

	@Autowired
	private DataExtractQueryODSToMongoDao dataExtractQueryODSToMongoDao;

	@Autowired
	private ReportMongoRepository mongoReport;

	@Autowired
	LeftOnDockUnPlannedRepository leftOnDockUnPlannedRepository;

	/**
	 * The logger.
	 */
	private final Logger logger = LoggerFactory.getLogger(getClass());

	public void processResults(QueryResult result, DataExtractRequest dataExtractRequest, int processedRecords,
			String fileName, String correlationId) {
		// Should be implement in child class
		throw new RuntimeException("should implement process results in child class.");
	}

	/**
	 * Process the extract Query SQL,generates the CSV file.
	 *
	 * @param dataExtractRequest the data extract request
	 */
	public void processExtractGeneration(DataExtractRequest dataExtractRequest, String correlationId) {
		logger.debug("Start DataExtractsGenerationController :: processExtractGeneration");

		// Fetch the Report object by report Id
		Optional<Report> reportData = getMongoReport().findByReportId(dataExtractRequest.getReportId());
		if (reportData.isPresent()) {
			Report report = reportData.get();
			String extractQuerySql = report.getQueryText();
			boolean isIncrementalExtract = report.isIncrementalExtractIndicator();
			String fileName = Objects.nonNull(dataExtractRequest.getFileName()) ? dataExtractRequest.getFileName()
					: DataExtractEngineUtil.INSTANCE.getLocalFileName(report.getReportName(), "csv");
			logger.info("fileName {}", fileName);
			// -1 in exception cases(IO/SQL exceptions)
			int processedRecords = -1;
			QueryResult result = new QueryResult();
			// Process the extract query
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			boolean excludeReportHeaders = dataExtractRequest.isExcludeReportHeaders();
			try {
				List<QueryParameter> queryParameters = dataExtractRequest.getQueryParameters();
				Date currentDateime = DataExtractEngineUtil.INSTANCE.getCurrentDateAndTime();
				if (isIncrementalExtract) {
					if (Objects.isNull(queryParameters)) {
						queryParameters = new ArrayList<>();
					}

					logger.debug("Incremental Extract boundaries: {} - {}",
							report.getPreviousIncrementalExtractCutOffTimestamp(),
							DataExtractEngineUtil.INSTANCE.getCurrentDateAndTime());
					addIncrementalExtractParameters(queryParameters,
							report.getPreviousIncrementalExtractCutOffTimestamp(), currentDateime);
				}
				SqlParameterSource namedParameters = setNamedParameters(queryParameters);
				SOURCE_TO_TRAGET daoType = SOURCE_TO_TRAGET.valueOf(report.getSourceToTraget());
				IDataExtractQueryDao dao = getDataExtractQueryDao(daoType);
				processedRecords = dao.executeExtractQuerySql(extractQuerySql, namedParameters, result,
						excludeReportHeaders);
				if (report.getReportName().equals("LeftOnDockUnPlanned")) {
					List<Document> datas = (ArrayList<Document>) result.getData();
					for (Document data : datas) {
						if (leftOnDockUnPlannedRepository.findByShpmId(data.get("SHPM_ID").toString()).size() > 0) {
							continue;
						} else {
							if (isIncrementalExtract) {
								report.setPreviousIncrementalExtractCutOffTimestamp(currentDateime);
								getMongoReport().save(report);
							}
							processResults(result, dataExtractRequest, processedRecords, fileName, correlationId);
						}
					}
				} else {
					if (isIncrementalExtract) {
						report.setPreviousIncrementalExtractCutOffTimestamp(currentDateime);
						getMongoReport().save(report);
					}
					processResults(result, dataExtractRequest, processedRecords, fileName, correlationId);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				logger.error("Exception in processExtractGeneration(): {}", ex.getMessage());
			} finally {
				stopWatch.stop();
				logger.info("Time taken to execute ExtractQuerySql and File generation {} ms", stopWatch.getTime());
			}
		} else {
			logger.error("DataExtractsGenerationProcessor :: Requested Report Id is not found in DB",
					dataExtractRequest.getReportId());
		}
	}

	/**
	 * Sets the namedParameters required for NamedJdbcParameterTemplate into
	 * MapSqlParameterSource.
	 *
	 * @param queryParms the query params
	 * @return namedParameters
	 */
	public SqlParameterSource setNamedParameters(List<QueryParameter> queryParms) {
		logger.debug("DataExtractsGenerationProcessor :: Setting named parameter");
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		if (!CollectionUtils.isEmpty(queryParms)) {
			for (QueryParameter queryParameter : queryParms) {
				if (Objects.isNull(queryParameter.getQueryParmValue())
						&& Objects.isNull(queryParameter.getQueryParmDateValue())) {
					namedParameters.addValue(queryParameter.getQueryParmCode(), null, Types.NULL);
				} else {
					switch (queryParameter.getQueryParmValueTypeCode()) {
					case DataExtractEngineConstants.DATE:
						namedParameters.addValue(queryParameter.getQueryParmCode(), queryParameter.getQueryParmValue(),
								Types.DATE);
						break;
					case DataExtractEngineConstants.CHAR:
						// To not append empty space if given string is less than column size
						namedParameters.addValue(queryParameter.getQueryParmCode(), queryParameter.getQueryParmValue(),
								OracleTypes.FIXED_CHAR);
						break;
					case DataExtractEngineConstants.TIMESTAMP:
						Calendar utcCal = Calendar.getInstance(TimeZone.getTimeZone(UTC));
						utcCal.setTime(queryParameter.getQueryParmDateValue());
						namedParameters.addValue(queryParameter.getQueryParmCode(), utcCal, Types.TIMESTAMP);
						break;
					default:
						namedParameters.addValue(queryParameter.getQueryParmCode(), queryParameter.getQueryParmValue());
					}
				}
			}
		}
		logger.info("Sql parameter source {}", namedParameters);
		return namedParameters;
	}

	/**
	 * Add two default mandatory parameters for the Incremental Extract.
	 * 
	 * @param queryParameters                           list of QueryParameter from
	 *                                                  the request
	 * @param previousIncrementalExtractCutOffTimestamp previous incremental extract
	 *                                                  cut off timestamp from the
	 *                                                  Report record
	 * @param newIncrementalExtractCutOffTimestamp      new incremental extract cut
	 *                                                  off timestamp from the
	 *                                                  request.
	 */
	public void addIncrementalExtractParameters(@NotNull List<QueryParameter> queryParameters,
			Date previousIncrementalExtractCutOffTimestamp, Date newIncrementalExtractCutOffTimestamp) {
		String fromDate = Objects.nonNull(previousIncrementalExtractCutOffTimestamp)
				? getDBFormatDate(previousIncrementalExtractCutOffTimestamp)
				: getDBFormatDate(MIN_DATE);
		queryParameters
				.add(new QueryParameter(INCREMENTAL_EXTRACT_FROM_TIMESTAMP, fromDate, DataExtractEngineConstants.CHAR));

		if (Objects.nonNull(newIncrementalExtractCutOffTimestamp)) {
			queryParameters.add(new QueryParameter(INCREMENTAL_EXTRACT_TO_TIMESTAMP,
					getDBFormatDate(newIncrementalExtractCutOffTimestamp), DataExtractEngineConstants.CHAR));
		}

		logger.debug("Adding Incremental Extract named parameters {}: {} and {}, {}",
				INCREMENTAL_EXTRACT_FROM_TIMESTAMP, fromDate, INCREMENTAL_EXTRACT_TO_TIMESTAMP,
				newIncrementalExtractCutOffTimestamp);
	}

	public String getDBFormatDate(Date dt) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return sdf.format(dt);
	}

	public ReportMongoRepository getMongoReport() {
		return mongoReport;
	}

	public IDataExtractQueryDao getDataExtractQueryDao(SOURCE_TO_TRAGET sourceToTarget) {
		switch (sourceToTarget) {
		case ODS_DB_TO_CSV:
			return dataExtractQueryDao;
		case ODS_DB_TO_MONGO_DB:
			return dataExtractQueryODSToMongoDao;
		case GOLDEN_GATE_TO_MONGO_DB:
			return dataExtractQueryGoldenGateToMongoDao;
		case GOLDEN_GATE_TO_CSV:
			return dataExtractQueryGoldenGateToCSVDao;
		case DC022_DB_TO_MONGO_DB:
			return dataExtractQueryDC022ToMongoDao;
		case DC028_DB_TO_MONGO_DB:
			return dataExtractQueryDC028ToMongoDao;
		default:
			return null;
		}
	}
	
	public boolean existInLODUnplanned(String shpmId, String reportName) {
		if (leftOnDockUnPlannedRepository.findByShpmId(shpmId).size() > 0 && reportName.equals("LeftOnDockUnPlanned")) {
			return true;
		}
		return false;
	}

}

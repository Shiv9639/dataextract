package com.lcl.scs.dataextractengine.domain;

import java.util.Date;
import java.util.StringJoiner;

import com.lcl.scs.dataextractengine.constants.DataExtractEngineConstants;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Extract query config parameters class.
 */
public class QueryParameter {

    /**
     * The query parm (parameter code/name).
     */
    @Schema(description = "Query parameter code")
    private String queryParmCode;

    /**
     * The query parm value for Strings.
     */
    @Schema(description = "Query parameter value")
    private String queryParmValue;

    /**
     * The query parm value for Timestamp.
     */
    @Schema(description = "Query parameter value of Date type."
        + " This property is currently used only within data-extract-engine internally for incremental extracts.", hidden = true)
    private Date queryParmDateValue;

    /**
     * The query parm type.
     * Current values: DataExtractEngineConstants.DATE, DataExtractEngineConstants.CHAR, DataExtractEngineConstants.TIMESTAMP
     */
    @Schema(description = "Query parameter value type code")
    private String queryParmValueTypeCode;

    /**
     * No-arg constructor.
     */
    public QueryParameter() {
    }

    /**
     * Convenience constructor for the Timestamp type parameters.
     * @param queryParmCode parameter code/name
     * @param queryParmDateValue parameter value of Date/Timestamp type
     */
    public QueryParameter(String queryParmCode, Date queryParmDateValue) {
        this.queryParmCode = queryParmCode;
        this.queryParmDateValue = queryParmDateValue;
        this.queryParmValueTypeCode = DataExtractEngineConstants.TIMESTAMP;
    }

    /**
     * Convenience constructor for types CHAR and DATE.
     * @param queryParmCode parameter code/name
     * @param queryParmValue parameter value
     * @param queryParmValueTypeCode parameter type code
     */
    public QueryParameter(String queryParmCode, String queryParmValue, String queryParmValueTypeCode) {
        this.queryParmCode = queryParmCode;
        this.queryParmValue = queryParmValue;
        this.queryParmValueTypeCode = queryParmValueTypeCode;
    }

    /**
     * Gets the query parm code.
     *
     * @return the query parm code
     */
    public String getQueryParmCode() {
        return queryParmCode;
    }

    /**
     * Sets the query parm code.
     *
     * @param queryParmCode the new query parm code
     */
    public void setQueryParmCode(String queryParmCode) {
        this.queryParmCode = queryParmCode;
    }

    /**
     * Gets the query parm value.
     *
     * @return the query parm value
     */
    public String getQueryParmValue() {
        return queryParmValue;
    }

    /**
     * Sets the query parm value.
     *
     * @param queryParmValue the new query parm value
     */
    public void setQueryParmValue(String queryParmValue) {
        this.queryParmValue = queryParmValue;
    }

    /**
     * Gets the query parameter date value.
     * @return date
     */
    public Date getQueryParmDateValue() {
        return queryParmDateValue;
    }

    /**
     * Sets the query parameter date value.
     * @param queryParmDateValue date value
     */
    public void setQueryParmDateValue(Date queryParmDateValue) {
        this.queryParmDateValue = queryParmDateValue;
    }

    /**
     * Gets the query parm value type code.
     *
     * @return the query parm value type code
     */
    public String getQueryParmValueTypeCode() {
        return queryParmValueTypeCode;
    }

    /**
     * Sets the query parm value type code.
     *
     * @param queryParmValueTypeCode the new query parm value type code
     */
    public void setQueryParmValueTypeCode(String queryParmValueTypeCode) {
        this.queryParmValueTypeCode = queryParmValueTypeCode;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return new StringJoiner(", ", "QueryParameter{", "}")
            .add("queryParmCode='" + queryParmCode + "'")
            .add("queryParmValue=" + queryParmValue)
            .add("queryParmDateValue='" + queryParmDateValue + "'")
            .add("queryParmValueTypeCode='" + queryParmValueTypeCode + "'")
            .toString();
    }
}

package com.lcl.scs.dataextractengine.report.processor;

import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.lcl.scs.dataextractengine.gcp.GCPFileDetails;
import com.lcl.scs.dataextractengine.gcp.GCPServiceFactory;
import com.lcl.scs.dataextractengine.report.constants.ReportConstants;
import com.lcl.scs.dataextractengine.report.domain.DataExtractCallBackResponse;

@Service
public class NetworkScheduleDCStoreMapReportPostProcessor extends DataExtractServicePostProcessor {

	@Autowired
	GCPServiceFactory gcpServiceFactory;

	@Value("${loblaw.appian.base.url}")
	private String appianBaseUrl;

	@Value("${loblaw.appian.api.key}")
	private String apiKey;

	private static final String APPIAN_NETWORK_SCHEDULE_STORE_TO_DC_MAP_URI = "lcl-dc-store-maps";

	private final Logger logger = LoggerFactory.getLogger(getClass());

	Supplier<String> getAppianUrl = () -> {
		return appianBaseUrl.concat(APPIAN_NETWORK_SCHEDULE_STORE_TO_DC_MAP_URI);
	};

	@Override
	public void processResponse(DataExtractCallBackResponse response) {

		try {
			GCPFileDetails fileDetails = gcpServiceFactory.getFilewithPath.apply(response.getFileName(),
					getDefaultFilePath.get());
			if (null != fileDetails) {
				logger.info("Loaded file from GCP: {}", fileDetails.getFilename());
				RestTemplate restTemplate = new RestTemplate();
				HttpHeaders headers = new HttpHeaders();
				headers.set(ReportConstants.APPIAN_API_KEY_HEADER, apiKey);
				headers.set(ReportConstants.APPIAN_DOCUMENT_NAME_KEY_HEADER, response.getFileName());
				headers.setContentType(MediaType.TEXT_EVENT_STREAM);
				HttpEntity<byte[]> entity = new HttpEntity<>(fileDetails.getData(), headers);
				ResponseEntity<String> appianresponse = restTemplate.postForEntity(getAppianUrl.get(), entity,
						String.class);
				if (appianresponse.getStatusCode().is2xxSuccessful()) {
					logger.info("Uploading file to Appian is successful : {} and the Response status is {}",
							fileDetails.getFilename(), appianresponse.getStatusCode());
				} else {
					logger.error("Uploading file to Appian is not successful : {} and the Response status is {}",
							fileDetails.getFilename(), appianresponse.getStatusCode());
				}

			} else {
				logger.error("file not found in GCP: {}", response.getFileName());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

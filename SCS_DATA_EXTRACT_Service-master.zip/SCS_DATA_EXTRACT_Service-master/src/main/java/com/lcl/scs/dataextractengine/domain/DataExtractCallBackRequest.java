package com.lcl.scs.dataextractengine.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import java.util.StringJoiner;

/**
 * The Class DataExtractCallBackRequest.
 */
@JsonInclude(NON_NULL)
public class DataExtractCallBackRequest {

    /**
     * Report Id.
     */
    private Long reportId;

    /**
     * The execution status sent in callback.
     */
    private boolean prcExecStatus;

    /**
     * The file name.
     */
    private String fileName;

    /**
     * The file sys rpt ind.
     */
    private boolean fileSysRptInd;

    /**
     * The processed record count.
     */
    private int processedRecordCount;

    /**
     * Checks if is execution status.
     *
     * @return true, if is execution status
     */
    public boolean isPrcExecStatus() {
        return prcExecStatus;
    }

    /**
     * Gets the report Id.
     * @return report id
     */
    public Long getReportId() {
        return reportId;
    }

    /**
     * Set the report Id.
     * @param reportId report Id
     */
    public void setReportId(Long reportId) {
        this.reportId = reportId;
    }

    /**
     * Sets the execution status.
     *
     * @param prcExecStatus the new execution status
     */
    public void setPrcExecStatus(boolean prcExecStatus) {
        this.prcExecStatus = prcExecStatus;
    }

    /**
     * Gets the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the new file name
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Checks if is file sys ind.
     *
     * @return true, if is file sys ind
     */
    public boolean isFileSysRptInd() {
        return fileSysRptInd;
    }

    /**
     * Sets the file sys ind.
     *
     * @param fileSysRptInd the new file sys ind
     */
    public void setFileSysRptInd(boolean fileSysRptInd) {
        this.fileSysRptInd = fileSysRptInd;
    }

    /**
     * Gets the processed record count.
     *
     * @return the processed record count
     */
    public int getProcessedRecordCount() {
        return processedRecordCount;
    }

    /**
     * Sets the processed record count.
     *
     * @param processedRecordCount the new processed record count
     */
    public void setProcessedRecordCount(int processedRecordCount) {
        this.processedRecordCount = processedRecordCount;
    }

    /**
     * (non-Javadoc).
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return new StringJoiner(", ", "DataExtractCallBackRequest{", "}")
            .add("biReportId=" + reportId)
            .add("prcExecStatus=" + prcExecStatus)
            .add("fileName='" + fileName + "'")
            .add("fileSysRptInd=" + fileSysRptInd)
            .add("processedRecordCount=" + processedRecordCount)
            .toString();
    }
}

package com.lcl.scs.dataextractengine.blackbox.dc022.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "dc022EntityManagerFactory", transactionManagerRef = "dc022TransactionManager", basePackages = {
		"com.lcl.scs.dataextractengine.blackbox.dc022" })
public class DC022Config {

	@Value("${spring.dc022.datasource.driverClassName}")
	private String driverClassName;

	@Value("${spring.dc022.datasource.url}")
	private String dbUrl;

	@Value("${spring.dc022.datasource.username}")
	private String userName;

	@Value("${spring.dc022.datasource.password}")
	private String password;

	@Bean(name = "dc022DataSource")
	@ConfigurationProperties(prefix = "spring.dc022.datasource")
	public DataSource dc022DataSource() {

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverClassName);
		dataSource.setUrl(dbUrl);
		dataSource.setUsername(userName);
		dataSource.setPassword(password);
		return dataSource;
	}

	@Bean(name = "dc022EntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean dc022EntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("dc022DataSource") DataSource dataSource) {
		return builder.dataSource(dataSource).packages("com.lcl.scs.dataextractengine.blackbox.dc022")
				.persistenceUnit("dc022").build();
	}

	@Bean(name = "namedJdbcdc022")
	@DependsOn("dc022DataSource")
	public NamedParameterJdbcTemplate namedParameterJdbcTemplate(
			@Qualifier("dc022DataSource") DataSource dc022DataSource) {
		return new NamedParameterJdbcTemplate(dc022DataSource);
	}

	@Bean(name = "dc022TransactionManager")
	public PlatformTransactionManager dc022TransactionManager(
			@Qualifier("dc022EntityManagerFactory") EntityManagerFactory dc022EntityManagerFactory) {
		return new JpaTransactionManager(dc022EntityManagerFactory);
	}
}
package com.lcl.scs.dataextractengine.report.processor;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.lcl.scs.dataextractengine.report.constants.DataExtractReportIdConstant;
import com.lcl.scs.dataextractengine.report.constants.PostBackServiceConstants;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

@Service
public class DCReportPreProcessing extends DataExtractServicePreProcessor {

	@Scheduled(cron = "0 5 2 * * ?")
	@SchedulerLock(name = "DCReportPreProcessing", lockAtLeastFor = "PT5M", lockAtMostFor = "PT5M")
	public void submitReport() {
		invokeDataExtractEngine.accept(DataExtractReportIdConstant.DC_REPORT, null);
	}

	@Override
	protected String getAbsolutePathForReportPostProcess() {
		// TODO Auto-generated method stub
		return PostBackServiceConstants.DC_REPORT_POST_BACK_URL;
	}

}

package com.lcl.scs.dataextractengine.sftp.exception;

public class SftpCoreException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String message;

	private Exception exception;

	public SftpCoreException() {
	}

	public SftpCoreException(Exception ex) {
		super(ex);
		this.exception = ex;
	}

	public SftpCoreException(String message) {
		super(message);
		this.message = message;
	}

	public SftpCoreException(String message, Exception ex) {
		super(message, ex);
		this.message = message;
		this.exception = ex;
	}

	@Override
	public String getMessage() {
		return message;

	}
}

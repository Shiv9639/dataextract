package com.lcl.scs.dataextractengine.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.lcl.scs.dataextractengine.interceptor.DataExtractServiceLoggingInterceptor;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

	private static final Logger logger = LoggerFactory.getLogger(DataExtractServiceLoggingInterceptor.class);

	@Autowired
	private DataExtractServiceLoggingInterceptor loggingInterceptor;

	@Override
	public void addInterceptors(InterceptorRegistry interceptorRegistry) {
		interceptorRegistry.addInterceptor(loggingInterceptor);
		logger.debug("WebMvc : Add Interceptor {}", interceptorRegistry);

	}
}

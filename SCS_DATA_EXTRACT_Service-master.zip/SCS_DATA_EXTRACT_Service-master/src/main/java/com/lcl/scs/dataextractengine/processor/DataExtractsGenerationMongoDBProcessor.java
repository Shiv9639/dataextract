package com.lcl.scs.dataextractengine.processor;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.domain.DeleteRecordRequest;
import com.lcl.scs.dataextractengine.domain.QueryResult;
import com.lcl.scs.dataextractengine.mongo.repository.ReportMongoRepository;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;

/**
 * Fetches the sql query from config tables , process the query and generates
 * the csv to store in file system. Finally invokes the callback for updating
 * the process execution with status and file name
 */
@Component
public class DataExtractsGenerationMongoDBProcessor extends DataExtractGenerationProcessor {

	/**
	 * The logger.
	 */
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ReportMongoRepository mongoReport;

	@Value("${spring.data.mongodb.uri}")
	private String mongodbURI;
	@Value("${spring.data.mongodb.database}")
	private String mongodbDatabase;
	
	@Autowired
	private MongoClient mongoClient;

	private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	private DateFormat ATSDATEFORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");

	public void processResults(QueryResult result, DataExtractRequest dataExtractRequest, int processedRecords,
			String fileName, String correlationId) {
		List<Document> documentList = (List<Document>) result.getData();
		if (!CollectionUtils.isEmpty(documentList)) {
			try {
				if(dataExtractRequest.isUpdateRecord()) {
					MongoCollection<Document> mongoCollection = mongoClient.getDatabase(mongodbDatabase).getCollection(dataExtractRequest.getCollectionName().getValue());
					documentList.forEach(doc -> {
						//Delete record if found
						mongoCollection.deleteOne(Filters.eq(dataExtractRequest.getPrimaryFieldName(), doc.getString(dataExtractRequest.getPrimaryFieldName())));
						//Insert record
						mongoCollection.insertOne(doc);
				  });
				} else {
					logger.info("Inserting multiple values into MongoDB collection : {}", dataExtractRequest.getCollectionName().getValue());
					mongoClient.getDatabase(mongodbDatabase).getCollection(dataExtractRequest.getCollectionName().getValue()).insertMany(documentList);
				}
				return;
			}
				catch(Exception ex)
				{
					ex.printStackTrace();
					logger.error("Exception in processResults(): {}", ex.getMessage());
					return;
				}
		}
	}
	
	public void processDeleteRecords(DeleteRecordRequest deleteRecordRequest) {
		logger.debug("Start DataExtractsGenerationController :: processDeleteRecords");
		try {
			MongoCollection<Document> document = mongoClient.getDatabase(mongodbDatabase).getCollection(deleteRecordRequest.getCollectionName().getValue());
			logger.info("Deleting records in MongoDb collection : " + deleteRecordRequest.getCollectionName().getValue());
			if(deleteRecordRequest.isDeleteAll())
			{
				document.drop();
				logger.info("Deleted all records from the collection : {}", deleteRecordRequest.getCollectionName().getValue());
			} else if (deleteRecordRequest.getFilter() != null) {
				document.deleteMany(deleteRecordRequest.getFilter());
			}
			else
			{
				if(deleteRecordRequest.getCollectionName().getValue()=="ATSEDI214") {
					Date atsDate=ATSDATEFORMAT.parse( ATSDATEFORMAT.format(System.currentTimeMillis() - 
							TimeUnit.DAYS.toMillis(deleteRecordRequest.getNumberOfDays())));
					document.deleteMany(Filters.lt(deleteRecordRequest.getFieldName(),atsDate));
					logger.info("Deleting records of last " + deleteRecordRequest.getNumberOfDays() +
							" days occured at : " +	atsDate);
				}
				else {
				document.deleteMany(Filters.lt(deleteRecordRequest.getFieldName(), dateFormat.format(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(deleteRecordRequest.getNumberOfDays()))));
				logger.info("Deleting records of last " + deleteRecordRequest.getNumberOfDays() + " days occured at : " + dateFormat.format(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(deleteRecordRequest.getNumberOfDays())));
			}
			}
			logger.debug("End DataExtractsGenerationController :: processDeleteRecords");
			return;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			logger.error("Exception in processDeleteRecords(): {}", ex.getMessage());
			return;
		}

	}
}

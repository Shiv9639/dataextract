package com.lcl.scs.dataextractengine.rest;



import javax.validation.Valid;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lcl.scs.dataextractengine.domain.DataExtractRequest;
import com.lcl.scs.dataextractengine.service.DataExtractsGenerationService;
import com.lcl.scs.dataextractengine.swagger.SwaggerApiResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;


/**
 * The Class DataExtractsRestController.
 */
@RestController
@Tag(name = "Data Extracts", description = "Data Extract Service Gateway - Data Extracts")
@RequestMapping("/data-extract-service")
@SwaggerApiResponse
public class DataExtractsRestController {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(getClass());

    /** The csv data extracts service. */
    @Autowired
    private DataExtractsGenerationService dataExtractsGenerationService;


    /**
     * Initialize Data Extract generation.
     *
     * @param dataExtractsRequest the data extracts request
     * @param userName the user name
     * @return the response entity
     */
    @PostMapping(value = "/extract", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Initializes data extract generation asynchonously.")
    @ApiResponses(value = {@ApiResponse(responseCode = "202")})
    public ResponseEntity<String> initializeDataExtractGeneration( @RequestHeader("X-Correlation-ID") String correlationId, @Valid @RequestBody DataExtractRequest dataExtractsRequest) {
        ResponseEntity<String> responseEntity = null;
        StopWatch watch = new StopWatch();
        watch.start();
        logger.info("DataExtractRequest : {}", dataExtractsRequest.toString());
        try {
           
            responseEntity = dataExtractsGenerationService.initiateExtractGeneration(dataExtractsRequest, correlationId);
        } catch (Exception ex) {
            logger.error("Exception initializeDataExtractGeneration", ex);
        } finally {
            watch.stop();
            logger.info("Completed the initializing of data extract engine in {} ms", watch.getTime());
        }
        return responseEntity;
    }
}

package com.lcl.scs.dataextractengine.goldengate.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "goldengateEntityManagerFactory", transactionManagerRef = "goldengateTransactionManager", basePackages = {
		"com.lcl.scs.dataextractengine.goldengate" })
public class GoldenGateConfig {

	@Value("${spring.goldengate.datasource.driverClassName}")
	private String driverClassName;
	
	@Value("${spring.goldengate.datasource.url}")
	private String dbUrl;
	
	@Value("${spring.goldengate.datasource.username}")
	private String userName;
	
	@Value("${spring.goldengate.datasource.password}")
	private String password;
	
	@Bean(name = "goldengateDataSource")
	@ConfigurationProperties(prefix = "spring.goldengate.datasource")
	public DataSource goldenGateDataSource() {

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverClassName);
		dataSource.setUrl(dbUrl);
		dataSource.setUsername(userName);
		dataSource.setPassword(password);
		return dataSource;
	}

	@Bean(name = "goldengateEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean goldenGateEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("goldengateDataSource") DataSource dataSource) {
		return builder.dataSource(dataSource).packages("com.lcl.scs.dataextractengine.goldengate").persistenceUnit("goldengate")
				.build();
	}
	
    @Bean(name = "namedJdbcgoldengate")
    @DependsOn("goldengateDataSource")
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(@Qualifier("goldengateDataSource") DataSource goldenGateDataSource) {
        return new NamedParameterJdbcTemplate(goldenGateDataSource);
    }

	@Bean(name = "goldengateTransactionManager")
	public PlatformTransactionManager goldenGateTransactionManager(
			@Qualifier("goldengateEntityManagerFactory") EntityManagerFactory odsEntityManagerFactory) {
		return new JpaTransactionManager(odsEntityManagerFactory);
	}
}
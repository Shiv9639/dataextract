package com.lcl.scs.dataextractengine.report.processor;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.lcl.scs.dataextractengine.report.constants.DataExtractReportIdConstant;
import com.lcl.scs.dataextractengine.report.constants.PostBackServiceConstants;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

@Service
public class CarrierMasterListReportPreProcessor  extends DataExtractServicePreProcessor {

	@Scheduled(cron = "0 1 2 * * ?")
	@SchedulerLock(name = "CarrierMasterListReportPreProcessor", lockAtLeastFor = "PT5M", lockAtMostFor = "PT5M")
	public void submitReport() {
		invokeDataExtractEngine.accept(DataExtractReportIdConstant.CARRIER_MASTER_LIST_REPORT, null);
	}

	@Override
	protected String getAbsolutePathForReportPostProcess() {
		return PostBackServiceConstants.CARRIER_MASTER_LIST_REPORT_POST_BACK_URL;
	}
}

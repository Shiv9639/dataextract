package com.lcl.scs.dataextractengine.scheduler;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.lcl.scs.dataextractengine.entity.R10175Events;
import com.lcl.scs.dataextractengine.entity.StoreMasterEvents;
import com.lcl.scs.dataextractengine.report.constants.ReportConstants;

@Service
public class CustomerMaster {

	private static final String MARKET = "MARKET";
	private static final String SHOPPERS = "SHOPPERS DRUG MART";
	private static final String EMERGING = "EMERGING";
	private static final String DISCOUNT = "DISCOUNT";
	private static final String ESCOMPTE = "ESCOMPTE";
	private static final String JOEFRESH = "JOE FRESH";

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Value("${loblaw.appian.base.url}")
	private String appianBaseUrl;

	@Value("${loblaw.appian.api.key}")
	private String apiKey;

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private static final String APPIAN_MASTER_LIST_URI = "sva-lcl-store-sync";

	Supplier<String> getAppianUrl = () -> {
		return appianBaseUrl.concat(APPIAN_MASTER_LIST_URI);
	};

	public byte[] csvToByteDatas() throws SAXException, IOException, ParserConfigurationException, ParseException {
		List<String[]> csvData = createCsvDataSimple();
		
		String citiesCommaSeparated = null;
		StringBuilder sb = new StringBuilder();
		for (String[] strs : csvData) {
			for (String str : strs) {
				citiesCommaSeparated = sb.append("\"").append(str).append("\"").append(",").toString().replace("null",
						"");
			}
		}
		citiesCommaSeparated = citiesCommaSeparated.substring(0, citiesCommaSeparated.length() - 1);
		char[] chars = citiesCommaSeparated.toCharArray();
		int count = 0;
		for (int i = 0; i < chars.length - 1; i++) {
			if (chars[i] == ',' && chars[i - 1] == '\"' && chars[i + 1] == '\"') {
				count++;
			}
			if (count == 18) {
				chars[i] = '\n';
				count = 0;
			}
		}
		byte[] bytes = String.valueOf(chars).getBytes();
		return bytes;
	}

	public List<String> getDatasFromDB() throws ParseException {
		List<String> datas = new ArrayList<>();
		Query query = new Query();
		query.addCriteria(Criteria.where("createdDate")
				.gt(LocalDateTime.now().minusDays(Integer.parseInt(System.getenv("NUMBER_OF_DAYS")))))
				.with(Sort.by(Sort.Direction.DESC, "createdDate"));
		List<R10175Events> queryEvents = mongoTemplate.find(query, R10175Events.class);
		for (R10175Events queryEvent : queryEvents) {
			datas.add(queryEvent.getContent());
		}
		return datas;
	}

	private List<String[]> createCsvDataSimple()
			throws SAXException, IOException, ParserConfigurationException, ParseException {
		String[] header = { "STORE_NUMBER", "STORE_NAME", "ADDRESS", "CITY", "PROVINCE", "POSTAL_CODE", "DIVISION",
				"REPORTING_REGION", "STORE_BANNER", "DISTRICT_MANAGER", "STORE_EMAIL", "MMS_STORE_NUMBER",
				"PRIMARY_STORE_NUMBER", "STATUS", "LATITUDE", "LONGITUDE", "TIMEZONE_OFFSET", "DAYLIGHT_OFFSET"};

		LocalDateTime localDateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		String formatDateTime = localDateTime.format(formatter);
		List<String[]> list = new ArrayList<>();
		list.add(header);
		List<String> datas = getDatasFromDB();
		for (int counter = 0; counter < datas.size(); counter++) {
			String xml = datas.get(counter);
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new InputSource(new StringReader(xml)));
			// NodeList rootElement =
			// document.getElementsByTagName("SapZmci1928Site01Z2t001w000");
			NodeList rootElement = document.getElementsByTagName("Z2KNA1_EXTR");
			for (int x = 0; x < rootElement.getLength(); x++) {
				Element convert = (Element) rootElement.item(x);
				String storeNumber = getStoreInfoFromXML(convert.getElementsByTagName("KUNNR").item(0));
				String storeName = getStoreInfoFromXML(convert.getElementsByTagName("NAME1").item(0)).toUpperCase();
				String address = getStoreInfoFromXML(convert.getElementsByTagName("STREET").item(0)).toUpperCase();
				String city = getStoreInfoFromXML(convert.getElementsByTagName("CITY1").item(0)).toUpperCase();
				String province = getStoreInfoFromXML(convert.getElementsByTagName("REGION").item(0));
				String postalCode = getStoreInfoFromXML(convert.getElementsByTagName("POST_CODE1").item(0));
				String reportingRegion = getStoreInfoFromXML(convert.getElementsByTagName("REGION").item(0));
				String email = getStoreInfoFromXML(convert.getElementsByTagName("SMTP_ADDR").item(0));
				String storeBanner = null;
				if (getStoreInfoFromXML(convert.getElementsByTagName("BRSCH").item(0)).toUpperCase().equals("AFFL")) {
					storeBanner = "AFFILIATE";
				} else if (getStoreInfoFromXML(convert.getElementsByTagName("BRSCH").item(0)).toUpperCase()
						.equals("SDM")) {
					storeBanner = "SHOPPERS DRUG MART";
				} else {
					storeBanner = getStoreInfoFromXML(convert.getElementsByTagName("BRSCH").item(0)).toUpperCase();
				}
				String status = getStoreInfoFromXML(convert.getElementsByTagName("ZZSTR_DACT_DT").item(0));
				String statusResult = "";
				String division = "";
				String Latitude = "";
				String Longitude = "";
				String primaryStoreNumber = "";
				String MMS_store_number = "";
				String TM_ZN_OFST = "";
				String DAYLGT_OFST = "";

				if (status == null || status.isEmpty() || status.equals("00000000")
						|| Integer.parseInt(status) > Integer.parseInt(formatDateTime)) {
					statusResult = "Active";
				} else if (status != null && !status.isEmpty()
						&& Integer.parseInt(status) < Integer.parseInt(formatDateTime)) {
					statusResult = "Inactive";
				}

				if (storeBanner.equals("YOUR IND GROCER") || storeBanner.equals("LOBLAW")
						|| storeBanner.equals("FORTINOS") || storeBanner.equals("VALU-MART")
						|| storeBanner.equals("ATLANTIC SUPERSTORE") || storeBanner.equals("ZEHRS")
						|| storeBanner.equals("DOMINION") || storeBanner.equals("ATL YOUR IND GROCER")
						|| storeBanner.equals("PROVIGO")) {
					division = MARKET;
				} else if (storeBanner.equals(SHOPPERS)) {
					division = SHOPPERS;
				} else if (storeBanner.equals("INDEPENDENTS(RETAIL)") || storeBanner.equals("RCLS")
						|| storeBanner.equals("WHOLESALE CLUB") || storeBanner.equals("INTERMARCHE")
						|| storeBanner.equals("AXEP") || storeBanner.equals("AFFILIATE")
						|| storeBanner.equals("IND FRANCHISE") || storeBanner.equals("WHOLESALE")) {
					division = EMERGING;
				} else if (storeBanner.equals("SUPERSTORE") || storeBanner.equals("NOFRILLS")
						|| storeBanner.equals("EXTRA FOODS")) {
					division = DISCOUNT;
				} else if (storeBanner.equals("MAXI") || storeBanner.equals("MAXI & CIE")) {
					division = ESCOMPTE;
				} else if (storeBanner.equals("JOE FRESH STANDALONE")) {
					division = JOEFRESH;
				}
				
				String query = "select shpg_loc_t.pmy_shpg_loc_cd, addr_t.LATITUDE, addr_t.LONGITUDE, shpg_loc_t.DAYLGT_OFST ,shpg_loc_t.TM_ZN_OFST \r\n"
						+ "from jdatm_prod.shpg_loc_t shpg_loc_t\r\n"
						+ "INNER JOIN jdatm_prod.addr_t addr_t ON shpg_loc_t.addr_id = addr_t.addr_id \r\n"
						+ "where shpg_loc_t.shpg_loc_cd = '" + String.join("", storeNumber) + "'";
				
				List<DoneDataMapping> result = jdbcTemplate.query(query, new Mapper());

				if (result != null && !result.isEmpty()) {
					if (result.get(0).getLatitude() != null && !result.get(0).getLatitude().isEmpty()) {
						Latitude = result.get(0).getLatitude();
					}
					if (result.get(0).getLongitude() != null && !result.get(0).getLongitude().isEmpty()) {
						Longitude = result.get(0).getLongitude();
					}
					if (result.get(0).getStopNumber() != null && !result.get(0).getStopNumber().isEmpty()) {
						primaryStoreNumber = result.get(0).getStopNumber();
					}
					if(result.get(0).getTimeZone() != null && !result.get(0).getTimeZone().isEmpty()) {
						TM_ZN_OFST = result.get(0).getTimeZone();
					}
					if(result.get(0).getDayLight() != null && !result.get(0).getDayLight().isEmpty()) {
						DAYLGT_OFST = result.get(0).getDayLight();
					}
				}
				
				Query queryMongo = new Query();

				String storeNumber4Digit = storeNumber.replaceFirst("^0+(?!$)", "");
				if (storeNumber4Digit.length() < 4) {
					queryMongo.addCriteria(Criteria.where("_id.internalLocationNumber")
							.is("0000".substring(storeNumber4Digit.length()) + storeNumber4Digit));
				} else {
					queryMongo.addCriteria(Criteria.where("_id.internalLocationNumber")
							.is(storeNumber.replaceFirst("^0+(?!$)", "")));

				}
				StoreMasterEvents queryEvent = mongoTemplate.findOne(queryMongo, StoreMasterEvents.class);

				if (queryEvent == null) {
					MMS_store_number = "";
				} else {
					MMS_store_number = queryEvent.getId().getSDMStoreNumber();
				}
				
				

				String[] record = { storeNumber, storeName, address, city, province, postalCode, division,
						reportingRegion, storeBanner, null, email, MMS_store_number, primaryStoreNumber, statusResult,
						Latitude, Longitude, TM_ZN_OFST, DAYLGT_OFST};

				list.add(record);
			}
		}

		return list;
	}

	public class DoneDataMapping implements Serializable {

		private static final long serialVersionUID = 1L;
		private String latitude;
		private String longitude;
		private String stopNumber;
		private String TM_ZN_OFST;
		private String DAYLGT_OFST;

		public String getLatitude() {
			return latitude;
		}

		public void setLatitude(String string) {
			this.latitude = string;
		}

		public String getLongitude() {
			return longitude;
		}

		public void setLongitude(String string) {
			this.longitude = string;
		}

		public String getStopNumber() {
			return stopNumber;
		}

		public void setStopNumber(String stopNumber) {
			this.stopNumber = stopNumber;
		}
		
		public String getTimeZone() {
			return TM_ZN_OFST;
		}

		public void setTimeZone(String TM_ZN_OFST) {
			this.TM_ZN_OFST = TM_ZN_OFST;
		}
		
		public String getDayLight() {
			return DAYLGT_OFST;
		}

		public void setDayLight(String DAYLGT_OFST) {
			this.DAYLGT_OFST = DAYLGT_OFST;
		}

	}

	public final class Mapper implements RowMapper<DoneDataMapping> {
		public DoneDataMapping mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			DoneDataMapping done = new DoneDataMapping();
			done.setLatitude(resultSet.getString("LATITUDE"));
			done.setLongitude(resultSet.getString("LONGITUDE"));
			done.setStopNumber(resultSet.getString("pmy_shpg_loc_cd"));
			done.setTimeZone(resultSet.getString("TM_ZN_OFST"));
			done.setDayLight(resultSet.getString("DAYLGT_OFST"));
			return done;
		}
	}

	public String getStoreInfoFromXML(Node n) {
		return n == null ? "" : n.getTextContent();
	}

	@Scheduled(cron = "0 1 1 * * ?")
	public void pushToAppian() throws SAXException, IOException, ParserConfigurationException, NumberFormatException,
			DataAccessException, ParseException {
		byte[] csvDatas = csvToByteDatas();
		if (csvDatas != null && System.getenv("CUSTOMER_MASTER").equals("Y")) {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
			LocalDateTime now = LocalDateTime.now();
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.set(ReportConstants.APPIAN_API_KEY_HEADER, apiKey);
			headers.set(ReportConstants.APPIAN_DOCUMENT_NAME_KEY_HEADER, "customer_master_list_" + dtf.format(now));
			headers.setContentType(new MediaType("text", "csv"));
			HttpEntity<byte[]> requestEntity = new HttpEntity<byte[]>(csvDatas, headers);
			ResponseEntity<String> appianresponse = restTemplate.postForEntity(getAppianUrl.get(), requestEntity,
					String.class);
			if (appianresponse.getStatusCode().is2xxSuccessful()) {
				logger.info("Pushing store master list to Appian was successful :  the Response status code is {}",
						appianresponse.getStatusCode());
			} else {
				logger.error("Pushing store master list to Appian was not successful : the Response status code is {}",
						appianresponse.getStatusCode());
			}
		}

	}
}
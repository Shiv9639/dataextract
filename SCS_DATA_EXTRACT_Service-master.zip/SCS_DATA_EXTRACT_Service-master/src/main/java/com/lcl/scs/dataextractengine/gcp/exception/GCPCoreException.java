package com.lcl.scs.dataextractengine.gcp.exception;

public class GCPCoreException  extends RuntimeException{
	
	private String message;
	
	private Exception exception;
	
	public GCPCoreException() {}
	
	public GCPCoreException(Exception ex) {
		super(ex);
		this.exception = ex;
	}
	
	public GCPCoreException(String message) {
		super(message);
		this.message = message;
	}
	
	public GCPCoreException(String message,Exception ex) {
		super(message, ex);
		this.message = message;
		this.exception = ex;
	}
	
	
	@Override
	public String getMessage() {
		return message;
		
	}

}

package com.lcl.scs.dataextractengine.sftp.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.lcl.scs.dataextractengine.sftp.document.SftpConnectionProperties;


public interface SftpConnectionPropertiesRepository extends MongoRepository<SftpConnectionProperties, String>{ 
	
	 @Query("{ 'CONNECTION_ID' : ?0 }")
	 Optional<SftpConnectionProperties> findByConnectionId(Long id);

}

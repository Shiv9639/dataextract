package com.lcl.scs.dataextractengine.gcp;

import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Bucket;
import com.google.cloud.storage.Storage;
import com.lcl.scs.dataextractengine.gcp.exception.GCPCoreException;

@Service
public class GCPServiceFactory {

	@Autowired
	private Storage storage;

	@Value("${gcp.default.buketname}")
	private String defaultBucketName;
	
	private final Logger logger = LoggerFactory.getLogger(getClass());

	Predicate<Bucket> isGCPBucketNotFound = gcpBucket -> Objects.isNull(gcpBucket);
	Predicate<Blob> isFileNotFound = file -> Objects.isNull(file);

	public boolean writeToGcs(String filename, String data) {
		writeToGcs(new GCPFileDetails(filename, null, defaultBucketName, data.getBytes()));
		return true;
	}

	public boolean writeToGcs(String filename, String filepath, String data) {
		writeToGcs(new GCPFileDetails(filename, filepath, defaultBucketName, data.getBytes()));
		return true;
	}

	public boolean writeToGcs(String filename, String filepath, byte[] data) {
		writeToGcs(new GCPFileDetails(filename, filepath, defaultBucketName, data));
		return true;
	}

	public boolean writeToGcs(GCPFileDetails gcpfileDetails) throws GCPCoreException {

		try {
			
			String fileName = StringUtils.isEmpty(gcpfileDetails.getFilePath()) ? gcpfileDetails.getFilename()
					: gcpfileDetails.getFilePath().concat(gcpfileDetails.getFilename());
			logger.info("Filename in GCP : {}", fileName);
			String bucketName = Optional.ofNullable(gcpfileDetails.getBucketName()).orElse(defaultBucketName);
			if (Objects.isNull(gcpfileDetails.getData())) {
				throw new GCPCoreException("No data to push to GCP. Empty file");
			}
			storage.create(BlobInfo.newBuilder(bucketName, fileName).build(), gcpfileDetails.getData());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw e;
		}
		return true;
	}

	public GCPFileDetails getFile(String filename) throws GCPCoreException {
		return getFile.apply(new GCPFileDetails(filename));
	}

	public GCPFileDetails getFile(String filename, String filePath) throws GCPCoreException {
		return getFile.apply(new GCPFileDetails(filename, filePath));
	}

	public GCPFileDetails getFile(String filename, String filePath, String bucketName) throws GCPCoreException {
		return getFile.apply(new GCPFileDetails(filename, filePath, bucketName));
	}

	Function<GCPFileDetails, String> buildFileWithPath = gcpfileDetails -> {
		String fileNameWithFilePath = gcpfileDetails.getFilePath().trim().concat(gcpfileDetails.getFilename().trim());
		logger.info("Is GCP file path empty? {}", gcpfileDetails.getFilePath().isEmpty());
		logger.info("Filename in GCP is : {}", gcpfileDetails.getFilename());
		logger.info("Concatenated filepath and filename in GCP : {}", fileNameWithFilePath);
		return gcpfileDetails.getFilePath().isEmpty() ? gcpfileDetails.getFilename().trim()
				: fileNameWithFilePath.trim();
	};

	Function<GCPFileDetails, String> getBucketName = gcpfileDetails -> {
		return Optional.ofNullable(gcpfileDetails.getBucketName()).orElse(defaultBucketName);
	};

	Function<GCPFileDetails, GCPFileDetails> getFile = gcpfileDetails -> {
		try {

			Bucket gcpBucket = storage.get(getBucketName.apply(gcpfileDetails));
			if (isGCPBucketNotFound.test(gcpBucket))
				throw new GCPCoreException("Storage bucket not found");

			Blob file = gcpBucket.get(buildFileWithPath.apply(gcpfileDetails));
			if (isFileNotFound.test(file))
				throw new GCPCoreException("file not found in GCP");

			// set the data to GCp file details
			gcpfileDetails.setData(file.getContent());
			storage.get(getBucketName.apply(gcpfileDetails)).get(buildFileWithPath.apply(gcpfileDetails)).getContent();
			return gcpfileDetails;
		} catch (Exception e) {
			logger.error("Error while accessing file from GCP", e);
			throw new GCPCoreException(e);
		}
	};

	public BiFunction<String, String, GCPFileDetails> getFilewithPath = (String filename, String filePath) -> {
		return getFile.apply(new GCPFileDetails(filename, filePath));
	};

	public Function<GCPFileDetails, Boolean> deleteFileInGCP = gcpfileDetails -> {

		Boolean isFileDeleted = Boolean.FALSE;

		Bucket gcpBucket = storage.get(getBucketName.apply(gcpfileDetails));
		if (isGCPBucketNotFound.test(gcpBucket))
			throw new GCPCoreException("Storage bucket not found");

		Blob file = gcpBucket.get(buildFileWithPath.apply(gcpfileDetails));
		if (isFileNotFound.test(file))
			throw new GCPCoreException("file not found in GCP");

		isFileDeleted = storage.delete(file.getBlobId());

		return isFileDeleted;

	};

}

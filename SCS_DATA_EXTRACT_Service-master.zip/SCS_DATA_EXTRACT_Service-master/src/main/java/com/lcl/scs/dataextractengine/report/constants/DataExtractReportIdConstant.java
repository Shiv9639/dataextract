package com.lcl.scs.dataextractengine.report.constants;

//Temporary solution need to have some concrete implementation.
public enum DataExtractReportIdConstant {
	DC_REPORT(1L), CARRIER_MASTER_LIST_REPORT(2L), NETWORK_SCHEDULE_DC_STORE_REPORT(6L);

	public final Long id;

	DataExtractReportIdConstant(long id) {
		this.id = id;
	}

	public Long getReportId() {
		return id;
	}
}

# Data Extract Engine

Data extract engine is a standalone spring boot application which receives request from any client for generating the extracts. The purpose of this engine is to reuse the data extract capabilities across the loblaws.

# Responsibilities of data extract engine:

- Consumes the request sent by the client application
- Read the sql from the configuration tables based on the reportId.
- Process the sql and generate the csv out of the resultset.
- Store the file in file system.
- Callback client application to update the process with status of the job

# Schedulers in Data Extract Service
> ###### BlackBoxDC022ScheduleDataExtractScheduler & BlackBoxDC028ScheduleDataExtractScheduler
- These schedulers runs once in every minute
- These schedulers are dedicated for data transfer from Blackbox DB to MongoDB collections

> ###### Carriers Master List Scheduler
- This scheduler runs once in a day at 2:01 AM EST
- This job process involves running a query against ODS to fetch carriers list and storing the output as .csv file in GCP and then posting it to Appian.

> ###### Distribution Centre List Scheduler
- This scheduler runs once in a day at 2:05 AM EST
- This job process involves running a query against ODS to fetch carriers list and storing the output as .csv file in GCP and then posting it to Appian.

> ###### Network Schedule DC to Store mapping Scheduler
- This scheduler runs once in a day at 1:15 AM EST
- This job process involves running a query against IPFPR Golden gate and fetching the data and storing the output as .csv file in GCP.

> ###### Network Schedule Data Extract Scheduler
- This scheduler runs once in a day at 3:00 AM EST
- This job process uses the file which was generated in GCP by Network Schedule DC to Store mapping scheduler (which occurs at 1:15 AM EST) and post the file to Appian.

> ###### SFTP Connection Scheduler for Fedex
- This scheduler runs once in every 1hr 10mins
- This job process includes connecting and fetching file from fedex server and update the file with a new additional column and saving it in GCP and then pushing the updated file from GCP to Appian.